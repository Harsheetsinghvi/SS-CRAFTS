import React from 'react';
import HeroSection from '@/components/HeroSection';
import CategoryGrid from '@/components/CategoryGrid';
import FeaturedShowcase from '@/components/FeaturedShowcase';
import CustomizerSection from '@/components/CustomizerSection';
import BulkGiftingSection from '@/components/BulkGiftingSection';
import WhyChooseUs from '@/components/WhyChooseUs';
import TestimonialsSection from '@/components/TestimonialsSection';
import FaqSection from '@/components/FaqSection';
import { getAllProducts, getAllCategories, getStoreSettings } from '@/lib/db';

export const revalidate = 60; // Refresh every 60 seconds

export default function HomePage() {
  const products = getAllProducts();
  const categories = getAllCategories();
  const settings = getStoreSettings();

  return (
    <>
      {/* 1. Hero Section */}
      <HeroSection whatsappNumber={settings.whatsappNumber} />

      {/* 2. Featured & Bestselling Products */}
      <FeaturedShowcase products={products} whatsappNumber={settings.whatsappNumber} />

      {/* 3. Product Categories Grid */}
      <CategoryGrid categories={categories} />

      {/* 4. Customization & Laser Cutting Service */}
      <CustomizerSection whatsappNumber={settings.whatsappNumber} />

      {/* 5. Corporate Gifting & Bulk Order Solution */}
      <BulkGiftingSection whatsappNumber={settings.whatsappNumber} />

      {/* 6. Why Choose Us */}
      <WhyChooseUs />

      {/* 7. Customer Testimonials */}
      <TestimonialsSection />

      {/* 8. Frequently Asked Questions */}
      <FaqSection whatsappNumber={settings.whatsappNumber} />
    </>
  );
}
