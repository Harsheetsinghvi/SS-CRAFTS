'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { MessageCircle, Menu, X, Layers, Box, Sparkles, Building2, Phone, ShieldCheck } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

interface HeaderProps {
  settings?: {
    storeName?: string;
    announcement?: string;
    whatsappNumber?: string;
    displayPhone?: string;
  };
}

export default function Header({ settings }: HeaderProps) {
  const pathname = usePathname();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const whatsappNum = settings?.whatsappNumber || '919313229609';
  const announcementText = settings?.announcement || '✨ SS Crafts | Handcrafted MDF Boxes, Laser-Cut Games, Piggy Banks & Custom Packaging | WhatsApp: +91 93132 29609';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Catalogue', href: '/catalogue' },
    { name: 'Custom Orders', href: '/custom-orders' },
    { name: 'Bulk & Corporate', href: '/bulk-gifting' },
    { name: 'About Us', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  return (
    <header className="site-header" style={{ position: 'sticky', top: 0, zIndex: 900, transition: 'var(--transition)' }}>
      {/* Top Announcement Bar */}
      <div
        style={{
          backgroundColor: 'var(--color-espresso)',
          color: 'var(--color-sand-beige)',
          fontSize: '0.82rem',
          padding: '0.45rem 1rem',
          textAlign: 'center',
          letterSpacing: '0.02em',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '1rem',
        }}
      >
        <span>{announcementText}</span>
        <a
          href={`https://wa.me/${sanitizeWhatsAppNumber(whatsappNum)}?text=${encodeURIComponent('Hello SS Crafts, I would like to enquire about your MDF catalogue and wholesale pricing.')}`}
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.35rem',
            color: '#A3D9A5',
            fontWeight: 600,
            textDecoration: 'underline',
            fontSize: '0.8rem',
          }}
        >
          <MessageCircle size={14} /> Quick Chat
        </a>
      </div>

      {/* Main Navigation Bar */}
      <nav
        style={{
          backgroundColor: isScrolled ? 'rgba(255, 253, 249, 0.95)' : 'var(--color-cream-white)',
          backdropFilter: 'blur(10px)',
          borderBottom: '1px solid var(--color-border)',
          boxShadow: isScrolled ? 'var(--shadow-sm)' : 'none',
          padding: '0.9rem 0',
          transition: 'var(--transition)',
        }}
      >
        <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          {/* Logo & Brand Identity */}
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div
              style={{
                width: '46px',
                height: '46px',
                borderRadius: '50%',
                overflow: 'hidden',
                backgroundColor: '#FFFFFF',
                boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                border: '1.5px solid var(--color-border)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                position: 'relative',
                flexShrink: 0,
              }}
            >
              <Image
                src="/logo.png"
                alt="SS Crafts Logo"
                width={46}
                height={46}
                style={{ objectFit: 'contain', width: '100%', height: '100%' }}
                priority
              />
            </div>
            <div>
              <span
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '1.45rem',
                  fontWeight: 700,
                  letterSpacing: '-0.02em',
                  color: 'var(--color-espresso)',
                  display: 'block',
                  lineHeight: 1.1,
                }}
              >
                {settings?.storeName || 'SS Crafts'}
              </span>
              <span
                style={{
                  fontSize: '0.68rem',
                  letterSpacing: '0.12em',
                  textTransform: 'uppercase',
                  color: 'var(--color-walnut-brown)',
                  fontWeight: 600,
                  display: 'block',
                }}
              >
                MDF Studio &bull; India
              </span>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <div style={{ display: 'none', alignItems: 'center', gap: '1.8rem' }} className="desktop-nav-items">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  style={{
                    fontSize: '0.92rem',
                    fontWeight: isActive ? 700 : 500,
                    color: isActive ? 'var(--color-walnut-brown)' : 'var(--color-espresso)',
                    position: 'relative',
                    padding: '0.4rem 0',
                  }}
                >
                  {link.name}
                  {isActive && (
                    <span
                      style={{
                        position: 'absolute',
                        bottom: 0,
                        left: 0,
                        width: '100%',
                        height: '2px',
                        backgroundColor: 'var(--color-walnut-brown)',
                        borderRadius: '2px',
                      }}
                    />
                  )}
                </Link>
              );
            })}
          </div>

          {/* Header Action Buttons */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            {/* WhatsApp Direct Header Button */}
            <a
              href={`https://wa.me/${sanitizeWhatsAppNumber(whatsappNum)}?text=${encodeURIComponent('Hello, I am interested in placing an order or inquiring about MDF products.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-whatsapp btn-sm"
              style={{ display: 'inline-flex' }}
            >
              <MessageCircle size={16} />
              <span className="btn-text-desktop">WhatsApp Enquiry</span>
            </a>

            {/* Admin Portal Shortcut Link */}
            <Link
              href="/admin/login"
              style={{
                fontSize: '0.78rem',
                color: 'var(--color-text-muted)',
                padding: '0.4rem 0.6rem',
                borderRadius: 'var(--radius-sm)',
                border: '1px solid var(--color-border-subtle)',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.3rem',
              }}
              title="Admin Portal"
            >
              <ShieldCheck size={14} />
              <span className="admin-text-desktop">Admin</span>
            </Link>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="mobile-menu-btn"
              style={{
                display: 'inline-flex',
                padding: '0.5rem',
                color: 'var(--color-espresso)',
              }}
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div
            style={{
              padding: '1.25rem 1.5rem',
              backgroundColor: 'var(--color-cream-white)',
              borderTop: '1px solid var(--color-border)',
              display: 'flex',
              flexDirection: 'column',
              gap: '1rem',
            }}
          >
            {navLinks.map((link) => (
              <Link
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                style={{
                  fontSize: '1rem',
                  fontWeight: pathname === link.href ? 700 : 500,
                  color: pathname === link.href ? 'var(--color-walnut-brown)' : 'var(--color-espresso)',
                  padding: '0.5rem 0',
                }}
              >
                {link.name}
              </Link>
            ))}
            <div style={{ paddingTop: '0.5rem', borderTop: '1px solid var(--color-border-subtle)' }}>
              <a
                href={`https://wa.me/${sanitizeWhatsAppNumber(whatsappNum)}?text=${encodeURIComponent('Hello, I would like to explore your MDF catalogue and pricing.')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-whatsapp"
                style={{ width: '100%', justifyContent: 'center' }}
              >
                <MessageCircle size={18} /> Chat on WhatsApp
              </a>
            </div>
          </div>
        )}
      </nav>

      <style jsx>{`
        @media (min-width: 860px) {
          .desktop-nav-items {
            display: flex !important;
          }
          .mobile-menu-btn {
            display: none !important;
          }
        }
        @media (max-width: 600px) {
          .btn-text-desktop,
          .admin-text-desktop {
            display: none;
          }
        }
      `}</style>
    </header>
  );
}
