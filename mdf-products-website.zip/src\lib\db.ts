import fs from 'fs';
import path from 'path';
import { Product, Category, StoreSettings, CustomerEnquiry, CustomQuoteRequest } from './types';

interface DatabaseData {
  settings: StoreSettings;
  categories: Category[];
  products: Product[];
  enquiries: CustomerEnquiry[];
  customQuotes: CustomQuoteRequest[];
}

const DB_PATH = path.join(process.cwd(), 'data', 'db.json');

// Ensure db directory exists
function ensureDbExists(): void {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// Read database
export function readDb(): DatabaseData {
  try {
    ensureDbExists();
    if (!fs.existsSync(DB_PATH)) {
      throw new Error(`DB file not found at ${DB_PATH}`);
    }
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    return JSON.parse(raw) as DatabaseData;
  } catch (error) {
    console.error('Error reading db.json:', error);
    // Return empty fallback structure
    return {
      settings: {
        storeName: 'SS Crafts',
        tagline: 'Crafting Ideas Into Beautiful MDF Products',
        announcement: '✨ SS Crafts | Handcrafted MDF Boxes, Laser-Cut Games, Piggy Banks & Custom Packaging | WhatsApp: +91 93132 29609',
        whatsappNumber: '919313229609',
        displayPhone: '+91 93132 29609',
        email: 'sscrafts104@gmail.com',
        address: 'Artisan Industrial Estate',
        city: 'Ahmedabad',
        state: 'Gujarat',
        pincode: '382445',
        gstin: '24AAJCV1234D1Z2',
        workingHours: 'Mon - Sat: 9:30 AM - 7:00 PM IST',
        socialLinks: {
          instagram: 'https://instagram.com/sscrafts_official',
          facebook: 'https://facebook.com/sscrafts',
          pinterest: 'https://pinterest.com/sscrafts',
        },
        adminEmail: 'admin@sscrafts.com',
        adminPasswordHash: '$2b$10$SIHsdCykgqtJQoEICd4QXeQyAj0i7LwV9rbPDAb1ZFDS3wP/p78km',
      },
      categories: [],
      products: [],
      enquiries: [],
      customQuotes: [],
    };
  }
}

// Write database safely
export function writeDb(data: DatabaseData): void {
  try {
    ensureDbExists();
    const tempPath = `${DB_PATH}.tmp`;
    fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
    fs.renameSync(tempPath, DB_PATH);
  } catch (error) {
    console.error('Error writing to db.json:', error);
    throw error;
  }
}

/* ================= PRODUCTS ================= */

export function getAllProducts(includeUnpublished = false): Product[] {
  const db = readDb();
  if (includeUnpublished) {
    return db.products;
  }
  return db.products.filter(p => p.published);
}

export function getProductById(id: string): Product | null {
  const db = readDb();
  return db.products.find(p => p.id === id || p.slug === id) || null;
}

export function saveProduct(product: Product): Product {
  const db = readDb();
  const existingIdx = db.products.findIndex(p => p.id === product.id);

  if (existingIdx >= 0) {
    product.updatedAt = new Date().toISOString();
    db.products[existingIdx] = product;
  } else {
    product.createdAt = new Date().toISOString();
    product.updatedAt = new Date().toISOString();
    db.products.push(product);
  }

  writeDb(db);
  return product;
}

export function deleteProduct(id: string): boolean {
  const db = readDb();
  const initialLength = db.products.length;
  db.products = db.products.filter(p => p.id !== id);
  if (db.products.length !== initialLength) {
    writeDb(db);
    return true;
  }
  return false;
}

/* ================= CATEGORIES ================= */

export function getAllCategories(): Category[] {
  const db = readDb();
  const products = db.products.filter(p => p.published);
  
  return db.categories
    .sort((a, b) => a.order - b.order)
    .map(c => ({
      ...c,
      productCount: products.filter(p => p.category === c.name).length,
    }));
}

export function getCategoryBySlug(slug: string): Category | null {
  const db = readDb();
  return db.categories.find(c => c.slug === slug || c.id === slug) || null;
}

export function saveCategory(category: Category): Category {
  const db = readDb();
  const existingIdx = db.categories.findIndex(c => c.id === category.id);

  if (existingIdx >= 0) {
    db.categories[existingIdx] = category;
  } else {
    db.categories.push(category);
  }

  writeDb(db);
  return category;
}

export function deleteCategory(id: string): boolean {
  const db = readDb();
  const initialLength = db.categories.length;
  db.categories = db.categories.filter(c => c.id !== id);
  if (db.categories.length !== initialLength) {
    writeDb(db);
    return true;
  }
  return false;
}

/* ================= SETTINGS ================= */

export function getStoreSettings(): StoreSettings {
  const db = readDb();
  return db.settings;
}

export function updateStoreSettings(newSettings: Partial<StoreSettings>): StoreSettings {
  const db = readDb();
  db.settings = { ...db.settings, ...newSettings };
  writeDb(db);
  return db.settings;
}

/* ================= ENQUIRIES ================= */

export function getAllEnquiries(): CustomerEnquiry[] {
  const db = readDb();
  return (db.enquiries || []).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
}

export function createEnquiry(enquiry: Omit<CustomerEnquiry, 'id' | 'createdAt'>): CustomerEnquiry {
  const db = readDb();
  if (!db.enquiries) db.enquiries = [];

  const newEnquiry: CustomerEnquiry = {
    ...enquiry,
    id: `ENQ-${Date.now().toString().slice(-4)}`,
    createdAt: new Date().toISOString(),
  };

  db.enquiries.unshift(newEnquiry);
  writeDb(db);
  return newEnquiry;
}

export function updateEnquiryStatus(
  id: string,
  status: CustomerEnquiry['status'],
  notes?: string
): CustomerEnquiry | null {
  const db = readDb();
  const enquiry = (db.enquiries || []).find(e => e.id === id);
  if (enquiry) {
    enquiry.status = status;
    if (notes !== undefined) enquiry.notes = notes;
    writeDb(db);
    return enquiry;
  }
  return null;
}

/* ================= CUSTOM QUOTES ================= */

export function createCustomQuote(quote: Omit<CustomQuoteRequest, 'id' | 'createdAt' | 'status'>): CustomQuoteRequest {
  const db = readDb();
  if (!db.customQuotes) db.customQuotes = [];

  const newQuote: CustomQuoteRequest = {
    ...quote,
    id: `CQ-${Date.now().toString().slice(-4)}`,
    status: 'Pending',
    createdAt: new Date().toISOString(),
  };

  db.customQuotes.unshift(newQuote);
  writeDb(db);
  return newQuote;
}

export function getAllCustomQuotes(): CustomQuoteRequest[] {
  const db = readDb();
  return db.customQuotes || [];
}
