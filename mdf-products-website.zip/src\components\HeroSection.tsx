'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { MessageCircle, ArrowRight, ShieldCheck, Sparkles, Box, Truck } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

interface HeroSectionProps {
  whatsappNumber: string;
}

export default function HeroSection({ whatsappNumber }: HeroSectionProps) {
  const cleanPhone = sanitizeWhatsAppNumber(whatsappNumber);
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent('Hello SS Crafts! I would like to explore your MDF products catalogue and enquire about custom laser cutting.')}`;

  return (
    <section
      style={{
        padding: '4rem 0 5rem',
        backgroundColor: 'var(--color-warm-ivory)',
        position: 'relative',
        overflow: 'hidden',
        borderBottom: '1px solid var(--color-border)',
      }}
    >
      {/* Subtle background ornamentation */}
      <div
        style={{
          position: 'absolute',
          top: '-10%',
          right: '-5%',
          width: '500px',
          height: '500px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(232, 222, 208, 0.6) 0%, rgba(247, 243, 236, 0) 70%)',
          pointerEvents: 'none',
        }}
      />

      <div className="container" style={{ position: 'relative', zIndex: 2 }}>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            alignItems: 'center',
            gap: '3.5rem',
          }}
        >
          {/* Left Column: Headline and CTAs */}
          <div>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.5rem',
                backgroundColor: 'rgba(138, 96, 69, 0.1)',
                color: 'var(--color-walnut-brown)',
                padding: '0.4rem 1rem',
                borderRadius: 'var(--radius-pill)',
                fontSize: '0.85rem',
                fontWeight: 600,
                marginBottom: '1.25rem',
              }}
            >
              <Sparkles size={16} />
              <span>SS Crafts &bull; Precision MDF Manufacturing</span>
            </div>

            <h1 className="display-title" style={{ marginBottom: '1.25rem' }}>
              Crafting Ideas Into Beautiful MDF Products.
            </h1>

            <p
              style={{
                fontSize: '1.15rem',
                color: 'var(--color-text-muted)',
                lineHeight: 1.65,
                marginBottom: '2.25rem',
                maxWidth: '560px',
              }}
            >
              Discover high-density MDF piggy banks, Diwali & Rakshabandhan boxes, luxury hamper boxes, desktop phone stands, awards & trophies, drawing sheets for colouring, MDF games, and custom cake toppers with factory-direct pricing.
            </p>

            {/* CTAs */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '3rem' }}>
              <Link href="/catalogue" className="btn btn-primary btn-lg">
                <span>Explore Products</span>
                <ArrowRight size={18} />
              </Link>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-whatsapp btn-lg"
              >
                <MessageCircle size={20} />
                <span>Enquire on WhatsApp</span>
              </a>
            </div>

            {/* Trust highlights */}
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
                gap: '1.5rem',
                paddingTop: '2rem',
                borderTop: '1px solid var(--color-border)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <div style={{ color: 'var(--color-walnut-brown)' }}><Box size={20} /></div>
                <div>
                  <strong style={{ fontSize: '0.9rem', display: 'block', color: 'var(--color-espresso)' }}>0.1mm Laser</strong>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>Micro Fretwork</span>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <div style={{ color: 'var(--color-walnut-brown)' }}><ShieldCheck size={20} /></div>
                <div>
                  <strong style={{ fontSize: '0.9rem', display: 'block', color: 'var(--color-espresso)' }}>Pine MDF</strong>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>Moisture Resistant</span>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <div style={{ color: 'var(--color-walnut-brown)' }}><Truck size={20} /></div>
                <div>
                  <strong style={{ fontSize: '0.9rem', display: 'block', color: 'var(--color-espresso)' }}>Pan-India</strong>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>Crate Dispatch</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Visual Montage */}
          <div style={{ position: 'relative' }}>
            <div
              style={{
                position: 'relative',
                borderRadius: '24px',
                overflow: 'hidden',
                boxShadow: 'var(--shadow-lg)',
                border: '8px solid #FFFFFF',
              }}
            >
              <div style={{ position: 'relative', width: '100%', height: '480px' }}>
                <Image
                  src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=1200&q=85"
                  alt="Crafting Ideas Into Beautiful MDF Products"
                  fill
                  priority
                  style={{ objectFit: 'cover' }}
                />
              </div>

              {/* Floating Floating card on visual */}
              <div
                style={{
                  position: 'absolute',
                  bottom: '1.5rem',
                  left: '1.5rem',
                  right: '1.5rem',
                  backgroundColor: 'rgba(255, 253, 249, 0.95)',
                  backdropFilter: 'blur(8px)',
                  padding: '1.25rem',
                  borderRadius: 'var(--radius-md)',
                  boxShadow: 'var(--shadow-md)',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <div>
                  <span style={{ fontSize: '0.72rem', textTransform: 'uppercase', color: 'var(--color-walnut-brown)', fontWeight: 700, letterSpacing: '0.08em' }}>
                    Artisan Signature Box
                  </span>
                  <h4 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.1rem', margin: '0.2rem 0', color: 'var(--color-espresso)' }}>
                    Mughal Jali Laser Cut Hamper
                  </h4>
                  <span style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)' }}>
                    Raw Sanded &bull; 5.5mm Engineered MDF
                  </span>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span style={{ fontSize: '1.3rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
                    ₹245
                  </span>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', display: 'block' }}>
                    MOQ: 10 pcs
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
