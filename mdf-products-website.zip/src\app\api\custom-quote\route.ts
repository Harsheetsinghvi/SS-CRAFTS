import { NextRequest, NextResponse } from 'next/server';
import { createCustomQuote, getAllCustomQuotes } from '@/lib/db';
import { checkAdminAuth } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const admin = checkAdminAuth(req);
    if (!admin) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const quotes = getAllCustomQuotes();
    return NextResponse.json({ success: true, quotes });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to fetch quotes' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body.name || !body.phone || !body.details) {
      return NextResponse.json({ success: false, error: 'Name, phone number, and requirement details are required' }, { status: 400 });
    }

    const quote = createCustomQuote({
      name: body.name,
      phone: body.phone,
      email: body.email || '',
      city: body.city || '',
      category: body.category || 'Custom Laser Cut',
      dimensions: body.dimensions || 'Custom Sizing',
      thickness: body.thickness || '5.5mm MDF',
      quantity: Number(body.quantity) || 50,
      finish: body.finish || 'Raw Sanded',
      details: body.details,
      referenceFileUrl: body.referenceFileUrl || '',
    });

    return NextResponse.json({ success: true, quote });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to submit quote request' }, { status: 500 });
  }
}
