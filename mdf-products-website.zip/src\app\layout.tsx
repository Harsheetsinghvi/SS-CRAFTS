import type { Metadata } from 'next';
import '@/styles/globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import FloatingWhatsApp from '@/components/FloatingWhatsApp';
import { getStoreSettings } from '@/lib/db';

export const metadata: Metadata = {
  title: 'SS Crafts | Crafting Ideas Into Beautiful MDF Products',
  description: 'Premium handcrafted MDF piggy banks, Diwali boxes, Rakshabandhan boxes, hampers, phone stands, awards, colouring sheets, MDF games, and cake toppers. Contact: +91 93132 29609.',
  keywords: 'SS Crafts, MDF piggy bank, Diwali boxes, Rakshabandhan box, hamper box, phone stand, MDF boxes, MDF award, MDF drawing sheet colouring, MDF games, cake topper, laser cut MDF India',
  openGraph: {
    title: 'SS Crafts | Crafting Ideas Into Beautiful MDF Products',
    description: 'Explore SS Crafts catalogue: MDF piggy banks, festive hamper boxes, phone stands, awards, colouring art bases, MDF games, and custom cake toppers with direct WhatsApp enquiries.',
    type: 'website',
  },
  icons: {
    icon: '/logo.png',
    apple: '/logo.png',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const settings = getStoreSettings();

  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>
        <Header settings={settings} />
        <main>{children}</main>
        <Footer settings={settings} />
        <FloatingWhatsApp whatsappNumber={settings.whatsappNumber} storeName={settings.storeName} />
      </body>
    </html>
  );
}
