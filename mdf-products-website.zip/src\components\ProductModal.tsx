'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import {
  X,
  MessageCircle,
  Ruler,
  Layers,
  Sparkles,
  Share2,
  Copy,
  Check,
  Building2,
  HelpCircle,
  Maximize2,
  ChevronRight,
  Shield,
  Truck
} from 'lucide-react';
import { Product } from '@/lib/types';
import { buildProductEnquiryMessage, generateWhatsAppLink } from '@/lib/whatsapp';

interface ProductModalProps {
  product: Product | null;
  whatsappNumber: string;
  onClose: () => void;
}

export default function ProductModal({ product, whatsappNumber, onClose }: ProductModalProps) {
  if (!product) return null;

  // Local configuration states
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [dimensionUnit, setDimensionUnit] = useState<'mm' | 'cm'>('mm');
  const [selectedFinish, setSelectedFinish] = useState(product.finishOptions[0] || 'Raw Sanded');
  const [selectedColor, setSelectedColor] = useState(product.colorOptions[0] || 'Natural Blonde');
  const [quantity, setQuantity] = useState(product.moq || 10);
  const [customDimensions, setCustomDimensions] = useState('');
  const [customNotes, setCustomNotes] = useState('');
  const [copied, setCopied] = useState(false);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  // Dimension conversions
  const { length, width, height } = product.dimensions;
  const isCm = dimensionUnit === 'cm';
  const displayLength = isCm ? (length / 10).toFixed(1) : length;
  const displayWidth = isCm ? (width / 10).toFixed(1) : width;
  const displayHeight = isCm ? (height / 10).toFixed(1) : height;

  // Build the dynamic WhatsApp message based on interactive selections
  const message = buildProductEnquiryMessage({
    product,
    quantity,
    finish: selectedFinish,
    color: selectedColor,
    customizationRequired: customNotes || (customDimensions ? `Custom Sizing: ${customDimensions}` : 'None (Standard catalogue design)'),
    customDimensions: customDimensions || undefined,
  });

  const whatsappUrl = generateWhatsAppLink(whatsappNumber, message);

  // Record enquiry analytics in database
  const handleWhatsAppEnquiry = async () => {
    try {
      await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          productName: product.name,
          productPrice: product.price,
          quantity,
          dimensions: customDimensions || `${length}x${width}x${height} mm`,
          material: product.material,
          finish: selectedFinish,
          color: selectedColor,
          customizationText: customNotes,
          source: 'whatsapp_click',
        }),
      });
    } catch (e) {}
  };

  const handleCopySpecs = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const images = product.images && product.images.length > 0 ? product.images : [
    'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80'
  ];

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="modal-product-title">
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ padding: '0', overflow: 'hidden' }}>
        {/* Close Button Header */}
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '1rem',
            right: '1rem',
            zIndex: 10,
            backgroundColor: 'rgba(255, 255, 255, 0.9)',
            border: '1px solid var(--color-border)',
            borderRadius: '50%',
            width: '36px',
            height: '36px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--color-espresso)',
            boxShadow: 'var(--shadow-sm)',
          }}
          aria-label="Close details"
        >
          <X size={20} />
        </button>

        {/* Modal Layout Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
          }}
        >
          {/* Left Column: Gallery & Visuals */}
          <div
            style={{
              padding: '2rem',
              backgroundColor: 'var(--color-warm-ivory)',
              display: 'flex',
              flexDirection: 'column',
              gap: '1.25rem',
              borderRight: '1px solid var(--color-border)',
            }}
          >
            {/* Main Stage Image */}
            <div
              style={{
                position: 'relative',
                width: '100%',
                paddingTop: '85%',
                borderRadius: 'var(--radius-md)',
                overflow: 'hidden',
                backgroundColor: '#FFFFFF',
                boxShadow: 'var(--shadow-sm)',
              }}
            >
              <Image
                src={images[activeImageIndex] || images[0]}
                alt={product.name}
                fill
                sizes="(max-width: 768px) 100vw, 50vw"
                style={{ objectFit: 'cover' }}
                priority
              />
            </div>

            {/* Thumbnail Switcher */}
            {images.length > 1 && (
              <div style={{ display: 'flex', gap: '0.6rem', overflowX: 'auto', paddingBottom: '0.2rem' }}>
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    style={{
                      position: 'relative',
                      width: '64px',
                      height: '64px',
                      flexShrink: 0,
                      borderRadius: 'var(--radius-sm)',
                      overflow: 'hidden',
                      border: activeImageIndex === idx ? '2px solid var(--color-walnut-brown)' : '1px solid var(--color-border)',
                      opacity: activeImageIndex === idx ? 1 : 0.65,
                      transition: 'var(--transition)',
                    }}
                  >
                    <Image src={img} alt={`View ${idx + 1}`} fill style={{ objectFit: 'cover' }} />
                  </button>
                ))}
              </div>
            )}

            {/* Key Quality Assurances */}
            <div
              style={{
                backgroundColor: '#FFFFFF',
                borderRadius: 'var(--radius-md)',
                padding: '1rem',
                border: '1px solid var(--color-border-subtle)',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
                fontSize: '0.82rem',
                color: 'var(--color-text-muted)',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Shield size={16} style={{ color: 'var(--color-whatsapp)' }} />
                <span>Export-Grade High Density MDF (Zero Splinters)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Truck size={16} style={{ color: 'var(--color-walnut-brown)' }} />
                <span>Pan-India Safe Wooden Crate & Carton Packing</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Sparkles size={16} style={{ color: 'var(--color-caramel)' }} />
                <span>CNC Laser Precision Tolerances (0.1mm Accuracy)</span>
              </div>
            </div>
          </div>

          {/* Right Column: Specifications & WhatsApp Order Config */}
          <div style={{ padding: '2rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
            {/* Header info */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.35rem' }}>
                <span className="badge badge-custom">{product.category}</span>
                <span style={{ fontSize: '0.78rem', color: 'var(--color-text-light)', fontFamily: 'monospace' }}>
                  SKU: {product.id}
                </span>
              </div>

              <h2 id="modal-product-title" style={{ fontFamily: 'var(--font-heading)', fontSize: '1.6rem', color: 'var(--color-espresso)', lineHeight: 1.25 }}>
                {product.name}
              </h2>

              {/* Price display */}
              <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.5rem', marginTop: '0.65rem' }}>
                <span style={{ fontSize: '1.75rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
                  ₹{product.price}
                </span>
                <span style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)' }}>
                  {product.priceUnit || 'per piece'}
                </span>
                <span style={{ marginLeft: 'auto', fontSize: '0.82rem', color: 'var(--color-whatsapp)', fontWeight: 600 }}>
                  ● {product.stockStatus}
                </span>
              </div>
            </div>

            {/* Description */}
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              {product.description}
            </p>

            {/* Dimensions with Unit Switcher */}
            <div
              style={{
                backgroundColor: 'var(--color-warm-ivory)',
                padding: '1rem',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border)',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.6rem' }}>
                <span style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--color-espresso)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <Ruler size={16} /> Dimensions & Thickness
                </span>
                <div style={{ display: 'flex', gap: '0.3rem', backgroundColor: '#FFFFFF', padding: '0.15rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border-subtle)' }}>
                  <button
                    onClick={() => setDimensionUnit('mm')}
                    style={{
                      padding: '0.2rem 0.5rem',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      borderRadius: '4px',
                      backgroundColor: dimensionUnit === 'mm' ? 'var(--color-espresso)' : 'transparent',
                      color: dimensionUnit === 'mm' ? '#FFFFFF' : 'var(--color-espresso)',
                    }}
                  >
                    mm
                  </button>
                  <button
                    onClick={() => setDimensionUnit('cm')}
                    style={{
                      padding: '0.2rem 0.5rem',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      borderRadius: '4px',
                      backgroundColor: dimensionUnit === 'cm' ? 'var(--color-espresso)' : 'transparent',
                      color: dimensionUnit === 'cm' ? '#FFFFFF' : 'var(--color-espresso)',
                    }}
                  >
                    cm
                  </button>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.5rem', textAlign: 'center', fontSize: '0.85rem' }}>
                <div style={{ background: '#FFFFFF', padding: '0.5rem', borderRadius: '6px' }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--color-text-light)', display: 'block' }}>Length</span>
                  <strong>{displayLength} {dimensionUnit}</strong>
                </div>
                <div style={{ background: '#FFFFFF', padding: '0.5rem', borderRadius: '6px' }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--color-text-light)', display: 'block' }}>Width</span>
                  <strong>{displayWidth} {dimensionUnit}</strong>
                </div>
                <div style={{ background: '#FFFFFF', padding: '0.5rem', borderRadius: '6px' }}>
                  <span style={{ fontSize: '0.72rem', color: 'var(--color-text-light)', display: 'block' }}>Height</span>
                  <strong>{displayHeight} {dimensionUnit}</strong>
                </div>
              </div>

              <div style={{ marginTop: '0.6rem', fontSize: '0.82rem', color: 'var(--color-text-muted)', display: 'flex', justifyContent: 'space-between' }}>
                <span>Thickness: <strong>{product.mdfThickness}</strong></span>
                <span>Material: <strong>{product.material.split('(')[0]}</strong></span>
              </div>
            </div>

            {/* Customization Options: Finish & Color */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.85rem' }}>
              <div>
                <label className="form-label" style={{ fontSize: '0.82rem' }}>Material Finish</label>
                <select
                  value={selectedFinish}
                  onChange={(e) => setSelectedFinish(e.target.value)}
                  className="form-select"
                  style={{ padding: '0.55rem', fontSize: '0.85rem' }}
                >
                  {product.finishOptions.map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="form-label" style={{ fontSize: '0.82rem' }}>Color / Stain</label>
                <select
                  value={selectedColor}
                  onChange={(e) => setSelectedColor(e.target.value)}
                  className="form-select"
                  style={{ padding: '0.55rem', fontSize: '0.85rem' }}
                >
                  {product.colorOptions.map((col) => (
                    <option key={col} value={col}>{col}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Custom Dimensions or Branding text */}
            {product.customizationAvailable && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: '0.65rem' }}>
                  <div>
                    <label className="form-label" style={{ fontSize: '0.82rem' }}>Custom Sizing (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g. 300x250x90 mm"
                      value={customDimensions}
                      onChange={(e) => setCustomDimensions(e.target.value)}
                      className="form-input"
                      style={{ padding: '0.55rem', fontSize: '0.85rem' }}
                    />
                  </div>
                  <div>
                    <label className="form-label" style={{ fontSize: '0.82rem' }}>Logo / Engraving Notes</label>
                    <input
                      type="text"
                      placeholder="e.g. Laser engrave 'Studio 9' on lid"
                      value={customNotes}
                      onChange={(e) => setCustomNotes(e.target.value)}
                      className="form-input"
                      style={{ padding: '0.55rem', fontSize: '0.85rem' }}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Quantity Selector & Live Total */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '0.75rem 1rem',
                backgroundColor: '#FFFFFF',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border)',
              }}
            >
              <div>
                <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', display: 'block' }}>
                  Order Quantity (MOQ: {product.moq} pcs)
                </span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.25rem' }}>
                  <button
                    onClick={() => setQuantity(Math.max(product.moq || 1, quantity - 5))}
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      backgroundColor: 'var(--color-warm-ivory)',
                      border: '1px solid var(--color-border)',
                      fontWeight: 700,
                    }}
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min={product.moq || 1}
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    style={{
                      width: '60px',
                      textAlign: 'center',
                      fontWeight: 700,
                      border: '1px solid var(--color-border-subtle)',
                      borderRadius: '4px',
                      padding: '0.2rem',
                    }}
                  />
                  <button
                    onClick={() => setQuantity(quantity + 5)}
                    style={{
                      width: '28px',
                      height: '28px',
                      borderRadius: '50%',
                      backgroundColor: 'var(--color-warm-ivory)',
                      border: '1px solid var(--color-border)',
                      fontWeight: 700,
                    }}
                  >
                    +
                  </button>
                </div>
              </div>

              <div style={{ textAlign: 'right' }}>
                <span style={{ fontSize: '0.78rem', color: 'var(--color-text-light)', display: 'block' }}>
                  Estimated Total
                </span>
                <span style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
                  ₹{(product.price * quantity).toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {/* Action Buttons: WhatsApp Direct & Copy Specs */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={handleWhatsAppEnquiry}
                className="btn btn-whatsapp btn-lg"
                style={{ width: '100%', justifyContent: 'center' }}
              >
                <MessageCircle size={20} />
                <span>Enquire on WhatsApp</span>
              </a>

              <div style={{ display: 'flex', gap: '0.5rem' }}>
                <button
                  onClick={handleCopySpecs}
                  className="btn btn-secondary btn-sm"
                  style={{ flex: 1, justifyContent: 'center' }}
                >
                  {copied ? <Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> : <Copy size={16} />}
                  <span>{copied ? 'Enquiry Copied!' : 'Copy Enquiry Message'}</span>
                </button>
              </div>

              <p style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', textAlign: 'center' }}>
                Clicking opens WhatsApp with your configured product specifications. You can attach reference images directly in the chat.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
