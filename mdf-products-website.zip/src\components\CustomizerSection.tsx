'use client';

import React, { useState } from 'react';
import { Sparkles, MessageCircle, Ruler, Scissors, Cpu, CheckCircle2, ArrowRight } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

interface CustomizerSectionProps {
  whatsappNumber: string;
}

export default function CustomizerSection({ whatsappNumber }: CustomizerSectionProps) {
  const [length, setLength] = useState(250);
  const [width, setWidth] = useState(200);
  const [height, setHeight] = useState(75);
  const [thickness, setThickness] = useState('5.5mm');
  const [serviceType, setServiceType] = useState('Laser Cut Hamper Box');
  const [quantity, setQuantity] = useState(50);
  const [brandingText, setBrandingText] = useState('');

  const cleanPhone = sanitizeWhatsAppNumber(whatsappNumber);

  // Generate WhatsApp message for custom requirement
  const customMessage = [
    'Hello SS Crafts, I would like a custom quote for laser cutting / bespoke MDF fabrication.',
    `Service/Product: ${serviceType}`,
    `Custom Dimensions: ${length} x ${width} x ${height} mm`,
    `Desired Thickness: ${thickness}`,
    `Estimated Quantity: ${quantity} units`,
    brandingText ? `Custom Branding / Engraving: ${brandingText}` : 'Branding: Plain / Will provide vector DXF/PDF later',
    'Please share feasibility, estimated price per piece, and sample timeline.',
  ].join('\n');

  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(customMessage)}`;

  return (
    <section
      style={{
        padding: '5.5rem 0',
        backgroundColor: 'var(--color-warm-ivory)',
        borderTop: '1px solid var(--color-border)',
        borderBottom: '1px solid var(--color-border)',
      }}
    >
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span
            style={{
              fontSize: '0.8rem',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: 'var(--color-walnut-brown)',
              fontWeight: 700,
              display: 'block',
              marginBottom: '0.5rem',
            }}
          >
            Precision Manufacturing
          </span>
          <h2 className="section-title">Bespoke Laser Cutting & Customization</h2>
          <p className="section-subtitle">
            Need non-standard box dimensions, company logo laser engraving, intricate jali frets, or pre-marked DIY art silhouettes? We craft custom batches from 20 to 5,000+ pieces.
          </p>
        </div>

        {/* 2-Column Showcase */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
            gap: '3rem',
            alignItems: 'center',
          }}
        >
          {/* Left: 4-Step Process Guide */}
          <div>
            <h3
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: '1.6rem',
                color: 'var(--color-espresso)',
                marginBottom: '1.5rem',
              }}
            >
              How Custom Orders Work
            </h3>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.4rem' }}>
              <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                <div
                  style={{
                    width: '38px',
                    height: '38px',
                    borderRadius: '50%',
                    backgroundColor: 'var(--color-walnut-brown)',
                    color: '#FFFFFF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 700,
                    flexShrink: 0,
                  }}
                >
                  1
                </div>
                <div>
                  <h4 style={{ fontSize: '1.05rem', color: 'var(--color-espresso)', marginBottom: '0.25rem' }}>
                    Choose Dimensions & Thickness
                  </h4>
                  <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                    Specify length, width, and depth in millimetres. Select thickness from 2.5mm for delicate fretwork to 12mm heavy base plates.
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                <div
                  style={{
                    width: '38px',
                    height: '38px',
                    borderRadius: '50%',
                    backgroundColor: 'var(--color-walnut-brown)',
                    color: '#FFFFFF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 700,
                    flexShrink: 0,
                  }}
                >
                  2
                </div>
                <div>
                  <h4 style={{ fontSize: '1.05rem', color: 'var(--color-espresso)', marginBottom: '0.25rem' }}>
                    Design & Lid Mechanics
                  </h4>
                  <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                    Select slide-in acrylic lids, antique brass hinges, magnetic flaps, or open partition trays. Share your vector CDR, DXF, or AI artwork.
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                <div
                  style={{
                    width: '38px',
                    height: '38px',
                    borderRadius: '50%',
                    backgroundColor: 'var(--color-walnut-brown)',
                    color: '#FFFFFF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 700,
                    flexShrink: 0,
                  }}
                >
                  3
                </div>
                <div>
                  <h4 style={{ fontSize: '1.05rem', color: 'var(--color-espresso)', marginBottom: '0.25rem' }}>
                    Sample Prototyping
                  </h4>
                  <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                    We produce physical pre-production samples within 48 to 72 hours for validation before mass production.
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '1rem', alignItems: 'flex-start' }}>
                <div
                  style={{
                    width: '38px',
                    height: '38px',
                    borderRadius: '50%',
                    backgroundColor: 'var(--color-whatsapp)',
                    color: '#FFFFFF',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 700,
                    flexShrink: 0,
                  }}
                >
                  4
                </div>
                <div>
                  <h4 style={{ fontSize: '1.05rem', color: 'var(--color-espresso)', marginBottom: '0.25rem' }}>
                    Bulk Dispatch & GST Invoice
                  </h4>
                  <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', lineHeight: 1.5 }}>
                    Crated safe dispatch via surface express with real-time tracking, tax invoices, and prompt WhatsApp assistance.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Interactive Custom Order Estimate Configurator */}
          <div
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 'var(--radius-lg)',
              padding: '2rem',
              boxShadow: 'var(--shadow-card)',
              border: '1px solid var(--color-border)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.25rem' }}>
              <Sparkles size={20} style={{ color: 'var(--color-walnut-brown)' }} />
              <h4 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.3rem', color: 'var(--color-espresso)', margin: 0 }}>
                Instant Custom Order Enquirer
              </h4>
            </div>

            <p style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem' }}>
              Configure your requirements below to instantly generate a WhatsApp message with all technical specs.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label className="form-label" style={{ fontSize: '0.82rem' }}>Product / Project Type</label>
                <select
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  className="form-select"
                  style={{ padding: '0.6rem' }}
                >
                  <option value="Laser Cut Hamper Box with Lid">Laser Cut Hamper Box with Lid</option>
                  <option value="Custom Partition Serving Tray">Custom Partition Serving Tray</option>
                  <option value="Pre-Marked DIY Art Bases (Rangoli/Mandala)">Pre-Marked DIY Art Bases (Rangoli/Mandala)</option>
                  <option value="Corporate Executive Desk Suite">Corporate Executive Desk Suite</option>
                  <option value="Wedding Trousseau Keepsake Crate">Wedding Trousseau Keepsake Crate</option>
                  <option value="Acrylic & MDF 3D Layered Nameplate">Acrylic & MDF 3D Layered Nameplate</option>
                  <option value="Bulk Blank Circular/Square Cutouts">Bulk Blank Circular/Square Cutouts</option>
                </select>
              </div>

              {/* Dimension Sliders / Inputs */}
              <div>
                <label className="form-label" style={{ fontSize: '0.82rem' }}>
                  Required Dimensions (Length × Width × Height in mm)
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.5rem' }}>
                  <div>
                    <input
                      type="number"
                      value={length}
                      onChange={(e) => setLength(Number(e.target.value))}
                      className="form-input"
                      placeholder="L mm"
                      style={{ padding: '0.5rem', textAlign: 'center' }}
                    />
                    <span style={{ fontSize: '0.7rem', color: 'var(--color-text-light)', display: 'block', textAlign: 'center', marginTop: '2px' }}>L (mm)</span>
                  </div>
                  <div>
                    <input
                      type="number"
                      value={width}
                      onChange={(e) => setWidth(Number(e.target.value))}
                      className="form-input"
                      placeholder="W mm"
                      style={{ padding: '0.5rem', textAlign: 'center' }}
                    />
                    <span style={{ fontSize: '0.7rem', color: 'var(--color-text-light)', display: 'block', textAlign: 'center', marginTop: '2px' }}>W (mm)</span>
                  </div>
                  <div>
                    <input
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(Number(e.target.value))}
                      className="form-input"
                      placeholder="H mm"
                      style={{ padding: '0.5rem', textAlign: 'center' }}
                    />
                    <span style={{ fontSize: '0.7rem', color: 'var(--color-text-light)', display: 'block', textAlign: 'center', marginTop: '2px' }}>H (mm)</span>
                  </div>
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                <div>
                  <label className="form-label" style={{ fontSize: '0.82rem' }}>MDF Thickness</label>
                  <select
                    value={thickness}
                    onChange={(e) => setThickness(e.target.value)}
                    className="form-select"
                    style={{ padding: '0.6rem' }}
                  >
                    <option value="2.5mm Pinewood MDF">2.5mm (Ultra-light fretwork)</option>
                    <option value="3.5mm Calibrated MDF">3.5mm (Standard box lids)</option>
                    <option value="5.5mm High-Density MDF">5.5mm (Heavy hampers / trays)</option>
                    <option value="8.0mm Heavy Base MDF">8.0mm (Rigid structural)</option>
                    <option value="12.0mm Dense Panel">12.0mm (Nameplates & clocks)</option>
                  </select>
                </div>

                <div>
                  <label className="form-label" style={{ fontSize: '0.82rem' }}>Expected Quantity</label>
                  <input
                    type="number"
                    min="10"
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="form-input"
                    style={{ padding: '0.6rem' }}
                  />
                </div>
              </div>

              <div>
                <label className="form-label" style={{ fontSize: '0.82rem' }}>Branding / Vector Notes</label>
                <input
                  type="text"
                  placeholder="e.g., Laser engrave logo, acrylic sliding lid, gold border"
                  value={brandingText}
                  onChange={(e) => setBrandingText(e.target.value)}
                  className="form-input"
                  style={{ padding: '0.6rem' }}
                />
              </div>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-whatsapp btn-lg"
                style={{ width: '100%', justifyContent: 'center', marginTop: '0.5rem' }}
              >
                <MessageCircle size={20} />
                <span>Enquire Custom Specs on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
