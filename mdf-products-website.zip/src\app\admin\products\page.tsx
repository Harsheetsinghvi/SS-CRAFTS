'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  EyeOff,
  Check,
  X,
  Upload,
  Ruler,
  AlertCircle,
  Sparkles,
  Star
} from 'lucide-react';
import { Product, Category } from '@/lib/types';

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');

  // Modal / Form state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deleteConfirmationId, setDeleteConfirmationId] = useState<string | null>(null);
  const [formSaving, setFormSaving] = useState(false);
  const [formError, setFormError] = useState('');

  // Form Fields
  const [formData, setFormData] = useState({
    id: '',
    name: '',
    category: 'MDF Gift Boxes',
    price: 199,
    priceUnit: 'per piece',
    moq: 10,
    length: 200,
    width: 200,
    height: 60,
    unit: 'mm' as 'mm' | 'cm',
    mdfThickness: '5.5mm High-Density MDF',
    material: 'Export Grade Pine MDF Board',
    finishOptions: 'Raw Sanded MDF, Clear Matte Lacquer, Walnut Stain',
    colorOptions: 'Natural Beige, Walnut Brown',
    customizationAvailable: true,
    featured: false,
    bestseller: false,
    isNew: true,
    published: true,
    stockStatus: 'In Stock' as 'In Stock' | 'Made to Order' | 'Bulk Only',
    images: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80',
    description: '',
  });

  const fetchProducts = async () => {
    try {
      const [prodRes, catRes] = await Promise.all([
        fetch('/api/products?admin=true'),
        fetch('/api/categories'),
      ]);
      const prodData = await prodRes.json();
      const catData = await catRes.json();

      if (prodData.success) setProducts(prodData.products);
      if (catData.success) setCategories(catData.categories);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const openAddModal = () => {
    setEditingProduct(null);
    setFormData({
      id: `MDF-${Date.now().toString().slice(-5)}`,
      name: '',
      category: categories[0]?.name || 'MDF Gift Boxes',
      price: 220,
      priceUnit: 'per piece',
      moq: 10,
      length: 250,
      width: 200,
      height: 70,
      unit: 'mm',
      mdfThickness: '5.5mm High-Density MDF',
      material: 'Export Grade Pine MDF Board',
      finishOptions: 'Raw Sanded MDF, Clear Matte Lacquer, Walnut Stain',
      colorOptions: 'Natural Beige, Walnut Brown',
      customizationAvailable: true,
      featured: false,
      bestseller: false,
      isNew: true,
      published: true,
      stockStatus: 'In Stock',
      images: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80',
      description: 'Precision laser crafted MDF design suitable for luxury gifting and crafts.',
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      id: product.id,
      name: product.name,
      category: product.category,
      price: product.price,
      priceUnit: product.priceUnit || 'per piece',
      moq: product.moq,
      length: product.dimensions.length,
      width: product.dimensions.width,
      height: product.dimensions.height,
      unit: product.dimensions.unit,
      mdfThickness: product.mdfThickness,
      material: product.material,
      finishOptions: product.finishOptions.join(', '),
      colorOptions: product.colorOptions.join(', '),
      customizationAvailable: product.customizationAvailable,
      featured: product.featured,
      bestseller: product.bestseller,
      isNew: product.isNew,
      published: product.published,
      stockStatus: product.stockStatus,
      images: product.images.join('\n'),
      description: product.description,
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const handleTogglePublish = async (product: Product) => {
    try {
      const res = await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ published: !product.published }),
      });
      if (res.ok) {
        setProducts(prev => prev.map(p => p.id === product.id ? { ...p, published: !p.published } : p));
      }
    } catch (e) {}
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        setProducts(prev => prev.filter(p => p.id !== id));
        setDeleteConfirmationId(null);
      }
    } catch (e) {}
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSaving(true);
    setFormError('');

    try {
      const imagesList = formData.images
        .split('\n')
        .map(url => url.trim())
        .filter(Boolean);

      const finishesList = formData.finishOptions
        .split(',')
        .map(f => f.trim())
        .filter(Boolean);

      const colorsList = formData.colorOptions
        .split(',')
        .map(c => c.trim())
        .filter(Boolean);

      const payload = {
        name: formData.name,
        category: formData.category,
        price: Number(formData.price),
        priceUnit: formData.priceUnit,
        moq: Number(formData.moq),
        dimensions: {
          length: Number(formData.length),
          width: Number(formData.width),
          height: Number(formData.height),
          unit: formData.unit,
        },
        mdfThickness: formData.mdfThickness,
        material: formData.material,
        finishOptions: finishesList.length > 0 ? finishesList : ['Raw Sanded'],
        colorOptions: colorsList.length > 0 ? colorsList : ['Natural Blonde'],
        customizationAvailable: formData.customizationAvailable,
        featured: formData.featured,
        bestseller: formData.bestseller,
        isNew: formData.isNew,
        published: formData.published,
        stockStatus: formData.stockStatus,
        images: imagesList.length > 0 ? imagesList : ['https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80'],
        description: formData.description,
      };

      let res;
      if (editingProduct) {
        res = await fetch(`/api/products/${editingProduct.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch('/api/products', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...payload, id: formData.id }),
        });
      }

      const data = await res.json();
      if (data.success) {
        setIsModalOpen(false);
        fetchProducts();
      } else {
        setFormError(data.error || 'Failed to save product');
      }
    } catch (err) {
      setFormError('Network error while saving product');
    } finally {
      setFormSaving(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fd = new FormData();
    fd.append('file', file);

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: fd,
      });
      const data = await res.json();
      if (data.success && data.url) {
        setFormData(prev => ({
          ...prev,
          images: prev.images ? `${prev.images}\n${data.url}` : data.url,
        }));
      }
    } catch (e) {
      alert('Upload failed');
    }
  };

  const filteredProducts = products.filter(p => {
    if (categoryFilter !== 'All' && p.category !== categoryFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
      {/* Header and Add Button */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem', color: 'var(--color-espresso)', margin: 0 }}>
            Product Catalogue Manager
          </h1>
          <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginTop: '0.2rem' }}>
            Add, update pricing, upload images, and control availability without modifying code.
          </p>
        </div>

        <button onClick={openAddModal} className="btn btn-primary btn-sm">
          <Plus size={16} />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 'var(--radius-md)',
          padding: '1rem',
          border: '1px solid var(--color-border)',
          display: 'flex',
          gap: '1rem',
          flexWrap: 'wrap',
          marginBottom: '1.5rem',
        }}
      >
        <div style={{ flex: '1 1 260px', position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', top: '50%', left: '0.8rem', transform: 'translateY(-50%)', color: 'var(--color-text-light)' }} />
          <input
            type="text"
            placeholder="Search by name or SKU..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="form-input"
            style={{ paddingLeft: '2.4rem', padding: '0.5rem 0.5rem 0.5rem 2.4rem', fontSize: '0.88rem' }}
          />
        </div>

        <div style={{ minWidth: '180px' }}>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="form-select"
            style={{ padding: '0.5rem', fontSize: '0.88rem' }}
          >
            <option value="All">All Categories ({products.length})</option>
            {categories.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Products Table */}
      <div className="admin-table-wrapper" style={{ boxShadow: 'var(--shadow-sm)' }}>
        <table className="admin-table">
          <thead>
            <tr>
              <th>Image</th>
              <th>SKU / ID</th>
              <th>Product Name</th>
              <th>Category</th>
              <th>Price</th>
              <th>Dimensions</th>
              <th>Thickness</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.map((p) => (
              <tr key={p.id}>
                <td style={{ width: '60px' }}>
                  <div style={{ position: 'relative', width: '50px', height: '50px', borderRadius: '6px', overflow: 'hidden', backgroundColor: 'var(--color-warm-ivory)' }}>
                    <Image
                      src={p.images[0] || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80'}
                      alt={p.name}
                      fill
                      style={{ objectFit: 'cover' }}
                    />
                  </div>
                </td>
                <td style={{ fontFamily: 'monospace', fontWeight: 600, color: 'var(--color-walnut-brown)' }}>
                  {p.id}
                </td>
                <td>
                  <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>{p.name}</strong>
                  <div style={{ display: 'flex', gap: '4px', marginTop: '3px' }}>
                    {p.bestseller && <span className="badge badge-bestseller" style={{ fontSize: '0.65rem' }}>Bestseller</span>}
                    {p.featured && <span className="badge badge-custom" style={{ fontSize: '0.65rem' }}>Featured</span>}
                  </div>
                </td>
                <td style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)' }}>
                  {p.category}
                </td>
                <td>
                  <strong style={{ color: 'var(--color-espresso)', fontSize: '0.95rem' }}>₹{p.price}</strong>
                  <span style={{ fontSize: '0.72rem', color: 'var(--color-text-light)', display: 'block' }}>MOQ: {p.moq}</span>
                </td>
                <td style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>
                  {p.dimensions.length}×{p.dimensions.width}×{p.dimensions.height} {p.dimensions.unit}
                </td>
                <td style={{ fontSize: '0.82rem' }}>
                  {p.mdfThickness.split(' ')[0]}
                </td>
                <td>
                  <button
                    onClick={() => handleTogglePublish(p)}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      gap: '0.3rem',
                      padding: '0.2rem 0.5rem',
                      borderRadius: 'var(--radius-pill)',
                      fontSize: '0.75rem',
                      fontWeight: 600,
                      backgroundColor: p.published ? '#E6EFE8' : '#FEE2E2',
                      color: p.published ? 'var(--color-whatsapp)' : '#B91C1C',
                    }}
                    title={p.published ? 'Click to hide from website' : 'Click to publish on website'}
                  >
                    {p.published ? <Eye size={12} /> : <EyeOff size={12} />}
                    <span>{p.published ? 'Published' : 'Hidden'}</span>
                  </button>
                </td>
                <td>
                  <div style={{ display: 'flex', gap: '0.4rem' }}>
                    <button
                      onClick={() => openEditModal(p)}
                      className="btn btn-secondary btn-sm"
                      style={{ padding: '0.35rem 0.55rem' }}
                      title="Edit Product"
                    >
                      <Edit2 size={14} />
                    </button>
                    <button
                      onClick={() => setDeleteConfirmationId(p.id)}
                      className="btn btn-secondary btn-sm"
                      style={{ padding: '0.35rem 0.55rem', color: '#DC2626' }}
                      title="Delete Product"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmationId && (
        <div className="modal-overlay" onClick={() => setDeleteConfirmationId(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '440px', padding: '2rem', textAlign: 'center' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '50%', backgroundColor: '#FEE2E2', color: '#DC2626', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
              <Trash2 size={24} />
            </div>
            <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.3rem', marginBottom: '0.5rem' }}>
              Confirm Product Deletion?
            </h3>
            <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem' }}>
              Are you sure you want to permanently delete SKU <strong>{deleteConfirmationId}</strong>? This action cannot be undone.
            </p>
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
              <button onClick={() => setDeleteConfirmationId(null)} className="btn btn-secondary">
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirmationId)}
                className="btn btn-primary"
                style={{ backgroundColor: '#DC2626', borderColor: '#DC2626' }}
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {isModalOpen && (
        <div className="modal-overlay" onClick={() => setIsModalOpen(false)}>
          <div
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
            style={{ maxWidth: '780px', padding: '2rem', maxHeight: '90vh', overflowY: 'auto' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', borderBottom: '1px solid var(--color-border)', paddingBottom: '0.8rem' }}>
              <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', margin: 0 }}>
                {editingProduct ? `Edit Product: ${editingProduct.id}` : 'Add New MDF Product'}
              </h2>
              <button onClick={() => setIsModalOpen(false)}><X size={20} /></button>
            </div>

            {formError && (
              <div style={{ backgroundColor: '#FEE2E2', color: '#DC2626', padding: '0.75rem', borderRadius: 'var(--radius-sm)', fontSize: '0.85rem', marginBottom: '1rem' }}>
                {formError}
              </div>
            )}

            <form onSubmit={handleSaveProduct} style={{ display: 'flex', flexDirection: 'column', gap: '1.1rem' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1rem' }}>
                <div>
                  <label className="form-label">Product Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="form-input"
                    placeholder="e.g. Royal Laser Cut Hamper Box with Acrylic Lid"
                  />
                </div>
                <div>
                  <label className="form-label">Product ID / SKU</label>
                  <input
                    type="text"
                    disabled={!!editingProduct}
                    value={formData.id}
                    onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                    className="form-input"
                    style={{ fontFamily: 'monospace' }}
                  />
                </div>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '1rem' }}>
                <div>
                  <label className="form-label">Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="form-select"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="form-label">Price (INR ₹) *</label>
                  <input
                    type="number"
                    required
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: Number(e.target.value) })}
                    className="form-input"
                  />
                </div>
                <div>
                  <label className="form-label">Minimum Order Qty (MOQ)</label>
                  <input
                    type="number"
                    required
                    value={formData.moq}
                    onChange={(e) => setFormData({ ...formData, moq: Number(e.target.value) })}
                    className="form-input"
                  />
                </div>
              </div>

              {/* Dimensions */}
              <div style={{ backgroundColor: 'var(--color-warm-ivory)', padding: '1rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
                <span style={{ fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '0.5rem' }}>
                  Product Dimensions & Units
                </span>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '0.75rem' }}>
                  <div>
                    <label style={{ fontSize: '0.75rem' }}>Length</label>
                    <input
                      type="number"
                      value={formData.length}
                      onChange={(e) => setFormData({ ...formData, length: Number(e.target.value) })}
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem' }}>Width</label>
                    <input
                      type="number"
                      value={formData.width}
                      onChange={(e) => setFormData({ ...formData, width: Number(e.target.value) })}
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem' }}>Height</label>
                    <input
                      type="number"
                      value={formData.height}
                      onChange={(e) => setFormData({ ...formData, height: Number(e.target.value) })}
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: '0.75rem' }}>Unit</label>
                    <select
                      value={formData.unit}
                      onChange={(e) => setFormData({ ...formData, unit: e.target.value as 'mm' | 'cm' })}
                      className="form-select"
                    >
                      <option value="mm">mm</option>
                      <option value="cm">cm</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Specifications: Thickness & Material */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label className="form-label">MDF Thickness</label>
                  <input
                    type="text"
                    value={formData.mdfThickness}
                    onChange={(e) => setFormData({ ...formData, mdfThickness: e.target.value })}
                    className="form-input"
                    placeholder="e.g. 5.5mm High-Density MDF"
                  />
                </div>
                <div>
                  <label className="form-label">Material & Board Type</label>
                  <input
                    type="text"
                    value={formData.material}
                    onChange={(e) => setFormData({ ...formData, material: e.target.value })}
                    className="form-input"
                    placeholder="e.g. Moisture Resistant Pine MDF Board"
                  />
                </div>
              </div>

              {/* Finish and Color Options */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div>
                  <label className="form-label">Finish Options (comma separated)</label>
                  <input
                    type="text"
                    value={formData.finishOptions}
                    onChange={(e) => setFormData({ ...formData, finishOptions: e.target.value })}
                    className="form-input"
                  />
                </div>
                <div>
                  <label className="form-label">Color Options (comma separated)</label>
                  <input
                    type="text"
                    value={formData.colorOptions}
                    onChange={(e) => setFormData({ ...formData, colorOptions: e.target.value })}
                    className="form-input"
                  />
                </div>
              </div>

              {/* Images Management */}
              <div>
                <label className="form-label">Image URLs (one per line) or Upload Image</label>
                <textarea
                  rows={2}
                  value={formData.images}
                  onChange={(e) => setFormData({ ...formData, images: e.target.value })}
                  className="form-textarea"
                  style={{ minHeight: '60px', fontFamily: 'monospace', fontSize: '0.8rem' }}
                />
                <div style={{ marginTop: '0.4rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <label className="btn btn-secondary btn-sm" style={{ cursor: 'pointer' }}>
                    <Upload size={14} />
                    <span>Upload Local Image File</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} style={{ display: 'none' }} />
                  </label>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>
                    JPG, PNG, or WEBP supported
                  </span>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="form-label">Product Description</label>
                <textarea
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="form-textarea"
                  placeholder="Detailed description, suitability for resin/crafts, lid mechanism, etc."
                />
              </div>

              {/* Badges and Flags */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1.25rem', padding: '0.75rem 1rem', backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border-subtle)' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}>
                  <input
                    type="checkbox"
                    checked={formData.bestseller}
                    onChange={(e) => setFormData({ ...formData, bestseller: e.target.checked })}
                  />
                  <span>Mark as Bestseller</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}>
                  <input
                    type="checkbox"
                    checked={formData.featured}
                    onChange={(e) => setFormData({ ...formData, featured: e.target.checked })}
                  />
                  <span>Mark as Featured</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}>
                  <input
                    type="checkbox"
                    checked={formData.customizationAvailable}
                    onChange={(e) => setFormData({ ...formData, customizationAvailable: e.target.checked })}
                  />
                  <span>Customization Allowed</span>
                </label>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem' }}>
                  <input
                    type="checkbox"
                    checked={formData.published}
                    onChange={(e) => setFormData({ ...formData, published: e.target.checked })}
                  />
                  <span>Publish on Live Website</span>
                </label>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '1rem', marginTop: '1rem', borderTop: '1px solid var(--color-border)', paddingTop: '1rem' }}>
                <button type="button" onClick={() => setIsModalOpen(false)} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" disabled={formSaving} className="btn btn-primary">
                  {formSaving ? 'Saving...' : editingProduct ? 'Save Product Changes' : 'Create Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
