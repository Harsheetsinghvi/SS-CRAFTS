import { NextRequest, NextResponse } from 'next/server';
import { getAllEnquiries, createEnquiry, updateEnquiryStatus } from '@/lib/db';
import { checkAdminAuth } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const admin = checkAdminAuth(req);
    if (!admin) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const enquiries = getAllEnquiries();
    return NextResponse.json({ success: true, enquiries });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to fetch enquiries' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    if (!body.productId || !body.productName) {
      return NextResponse.json({ success: false, error: 'Product details required' }, { status: 400 });
    }

    const newEnquiry = createEnquiry({
      productId: body.productId,
      productName: body.productName,
      productPrice: Number(body.productPrice) || 0,
      quantity: Number(body.quantity) || 1,
      dimensions: body.dimensions || '',
      material: body.material || '',
      finish: body.finish || '',
      color: body.color || '',
      customizationText: body.customizationText || '',
      customerName: body.customerName || 'Direct WhatsApp Visitor',
      customerPhone: body.customerPhone || '',
      customerCity: body.customerCity || '',
      status: 'New',
      source: body.source || 'whatsapp_click',
      notes: body.notes || 'Initiated enquiry via WhatsApp button',
    });

    return NextResponse.json({ success: true, enquiry: newEnquiry });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to record enquiry' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const admin = checkAdminAuth(req);
    if (!admin) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { id, status, notes } = body;

    if (!id || !status) {
      return NextResponse.json({ success: false, error: 'ID and status required' }, { status: 400 });
    }

    const updated = updateEnquiryStatus(id, status, notes);
    if (!updated) {
      return NextResponse.json({ success: false, error: 'Enquiry not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, enquiry: updated });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to update enquiry' }, { status: 500 });
  }
}
