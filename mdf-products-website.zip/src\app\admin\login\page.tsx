'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { ShieldCheck, Lock, Mail, ArrowRight, Box, AlertCircle } from 'lucide-react';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (data.success) {
        // Also store token in localStorage as backup
        if (data.token) {
          localStorage.setItem('mdf_admin_token', data.token);
        }
        router.push('/admin/dashboard');
      } else {
        setError(data.error || 'Invalid credentials. Please verify your email and password.');
      }
    } catch (err) {
      setError('Connection error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: '80vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '2rem 1rem',
        backgroundColor: 'var(--color-warm-ivory)',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: '440px',
          backgroundColor: '#FFFFFF',
          borderRadius: 'var(--radius-lg)',
          padding: '2.5rem',
          boxShadow: 'var(--shadow-lg)',
          border: '1px solid var(--color-border)',
        }}
      >
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div
            style={{
              width: '68px',
              height: '68px',
              backgroundColor: '#FFFFFF',
              borderRadius: '50%',
              overflow: 'hidden',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1.25rem',
              boxShadow: '0 4px 14px rgba(0,0,0,0.1)',
              border: '2px solid var(--color-walnut-brown)',
            }}
          >
            <Image
              src="/logo.png"
              alt="SS Crafts Logo"
              width={68}
              height={68}
              style={{ objectFit: 'contain', width: '100%', height: '100%' }}
              priority
            />
          </div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.6rem', color: 'var(--color-espresso)', margin: 0 }}>
            Admin Management Portal
          </h1>
          <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginTop: '0.4rem' }}>
            SS Crafts MDF Catalogue Control
          </p>
        </div>

        {error && (
          <div
            style={{
              backgroundColor: '#FDF2F2',
              color: '#9B1C1C',
              padding: '0.75rem 1rem',
              borderRadius: 'var(--radius-md)',
              fontSize: '0.85rem',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              marginBottom: '1.5rem',
              border: '1px solid #F8B4B4',
            }}
          >
            <AlertCircle size={16} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '1.2rem' }}>
          <div>
            <label className="form-label" style={{ fontSize: '0.85rem' }}>Administrator Email</label>
            <div style={{ position: 'relative' }}>
              <Mail size={18} style={{ position: 'absolute', top: '50%', left: '0.85rem', transform: 'translateY(-50%)', color: 'var(--color-text-light)' }} />
              <input
                type="email"
                required
                placeholder="admin@sscrafts.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="form-input"
                style={{ paddingLeft: '2.4rem' }}
              />
            </div>
          </div>

          <div>
            <label className="form-label" style={{ fontSize: '0.85rem' }}>Password</label>
            <div style={{ position: 'relative' }}>
              <Lock size={18} style={{ position: 'absolute', top: '50%', left: '0.85rem', transform: 'translateY(-50%)', color: 'var(--color-text-light)' }} />
              <input
                type="password"
                required
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="form-input"
                style={{ paddingLeft: '2.4rem' }}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary btn-lg"
            style={{ width: '100%', justifyContent: 'center', marginTop: '0.5rem' }}
          >
            <span>{loading ? 'Authenticating...' : 'Sign In to Dashboard'}</span>
            <ArrowRight size={18} />
          </button>
        </form>

        <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: 'var(--color-warm-ivory)', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border-subtle)', fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
          <strong style={{ display: 'block', color: 'var(--color-espresso)', marginBottom: '0.2rem' }}>Default Seeded Credentials:</strong>
          Email: <code>admin@sscrafts.com</code>
          <br />
          Password: <code>Admin@MDF2025</code>
          <br />
          <span style={{ fontSize: '0.72rem', color: 'var(--color-text-light)', marginTop: '0.3rem', display: 'block' }}>
            (You can update this password inside Settings anytime)
          </span>
        </div>
      </div>
    </div>
  );
}
