'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import {
  Box,
  Layers,
  MessageCircle,
  TrendingUp,
  Plus,
  ArrowRight,
  Clock,
  CheckCircle2,
  Phone,
  AlertCircle
} from 'lucide-react';
import { Product, Category, CustomerEnquiry, StoreSettings } from '@/lib/types';

export default function AdminDashboardPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [enquiries, setEnquiries] = useState<CustomerEnquiry[]>([]);
  const [settings, setSettings] = useState<StoreSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/products?admin=true').then(r => r.json()),
      fetch('/api/categories').then(r => r.json()),
      fetch('/api/enquiries').then(r => r.json()),
      fetch('/api/settings').then(r => r.json()),
    ])
      .then(([prodData, catData, enqData, setData]) => {
        if (prodData.success) setProducts(prodData.products);
        if (catData.success) setCategories(catData.categories);
        if (enqData.success) setEnquiries(enqData.enquiries);
        if (setData.success) setSettings(setData.settings);
        setLoading(false);
      })
      .catch((e) => {
        console.error(e);
        setLoading(false);
      });
  }, []);

  const handleUpdateStatus = async (id: string, newStatus: CustomerEnquiry['status']) => {
    try {
      const res = await fetch('/api/enquiries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      });
      if (res.ok) {
        setEnquiries(prev => prev.map(e => e.id === id ? { ...e, status: newStatus } : e));
      }
    } catch (e) {}
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '4rem 0' }}>
        <p style={{ fontFamily: 'var(--font-heading)', fontSize: '1.2rem', color: 'var(--color-espresso)' }}>
          Loading dashboard metrics...
        </p>
      </div>
    );
  }

  const publishedCount = products.filter(p => p.published).length;
  const bestsellersCount = products.filter(p => p.bestseller).length;

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
      {/* Welcome Title */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem', color: 'var(--color-espresso)', margin: 0 }}>
            Catalogue Overview
          </h1>
          <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginTop: '0.2rem' }}>
            Live status of your MDF products, customer enquiries, and catalogue settings.
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem' }}>
          <Link href="/admin/products" className="btn btn-primary btn-sm">
            <Plus size={16} />
            <span>Manage Products</span>
          </Link>
          <Link href="/admin/settings" className="btn btn-secondary btn-sm">
            <Phone size={16} />
            <span>WhatsApp Settings</span>
          </Link>
        </div>
      </div>

      {/* Metric Cards Grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '1.5rem',
          marginBottom: '2.5rem',
        }}
      >
        <div style={{ backgroundColor: '#FFFFFF', padding: '1.5rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', fontWeight: 600 }}>Total Products</span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(138, 96, 69, 0.12)', color: 'var(--color-walnut-brown)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Box size={20} />
            </div>
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
            {products.length}
          </div>
          <span style={{ fontSize: '0.78rem', color: 'var(--color-whatsapp)', fontWeight: 600 }}>
            {publishedCount} Published Live &bull; {bestsellersCount} Bestsellers
          </span>
        </div>

        <div style={{ backgroundColor: '#FFFFFF', padding: '1.5rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', fontWeight: 600 }}>Active Categories</span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(138, 96, 69, 0.12)', color: 'var(--color-walnut-brown)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Layers size={20} />
            </div>
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
            {categories.length}
          </div>
          <Link href="/admin/categories" style={{ fontSize: '0.78rem', color: 'var(--color-walnut-brown)', fontWeight: 600 }}>
            Manage Categories &rarr;
          </Link>
        </div>

        <div style={{ backgroundColor: '#FFFFFF', padding: '1.5rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', fontWeight: 600 }}>Recorded Enquiries</span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(79, 118, 88, 0.12)', color: 'var(--color-whatsapp)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <MessageCircle size={20} />
            </div>
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
            {enquiries.length}
          </div>
          <span style={{ fontSize: '0.78rem', color: 'var(--color-text-muted)' }}>
            WhatsApp clicks & quotes logged
          </span>
        </div>

        <div style={{ backgroundColor: '#FFFFFF', padding: '1.5rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', fontWeight: 600 }}>Configured WhatsApp</span>
            <div style={{ width: '36px', height: '36px', borderRadius: '8px', backgroundColor: 'rgba(79, 118, 88, 0.12)', color: 'var(--color-whatsapp)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Phone size={18} />
            </div>
          </div>
          <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-espresso)', fontFamily: 'monospace' }}>
            +{settings?.whatsappNumber || '919313229609'}
          </div>
          <span style={{ fontSize: '0.78rem', color: 'var(--color-whatsapp)', fontWeight: 600 }}>
            ● Active across all buttons
          </span>
        </div>
      </div>

      {/* Recent Enquiries & Leads Section */}
      <div style={{ backgroundColor: '#FFFFFF', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-sm)', padding: '1.75rem', marginBottom: '2.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.3rem', margin: 0 }}>
              Recent WhatsApp & Form Enquiries
            </h2>
            <p style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', marginTop: '0.2rem' }}>
              Real-time records generated when customers click &ldquo;Enquire on WhatsApp&rdquo; or request bulk quotes.
            </p>
          </div>
          <Link href="/admin/enquiries" style={{ fontSize: '0.85rem', color: 'var(--color-walnut-brown)', fontWeight: 600 }}>
            View All ({enquiries.length}) &rarr;
          </Link>
        </div>

        {enquiries.length > 0 ? (
          <div className="admin-table-wrapper">
            <table className="admin-table">
              <thead>
                <tr>
                  <th>Enquiry ID</th>
                  <th>Product Name</th>
                  <th>Quantity</th>
                  <th>Finish & Details</th>
                  <th>Customer Info</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {enquiries.slice(0, 6).map((enq) => (
                  <tr key={enq.id}>
                    <td style={{ fontFamily: 'monospace', fontWeight: 600, color: 'var(--color-walnut-brown)' }}>
                      {enq.id}
                    </td>
                    <td>
                      <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>{enq.productName}</strong>
                      <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>SKU: {enq.productId}</span>
                    </td>
                    <td style={{ fontWeight: 600 }}>
                      {enq.quantity} pcs
                    </td>
                    <td style={{ fontSize: '0.82rem', maxWidth: '240px' }}>
                      <span style={{ color: 'var(--color-espresso)', fontWeight: 600 }}>{enq.finish || 'Raw'}</span>
                      {enq.customizationText && (
                        <span style={{ display: 'block', color: 'var(--color-text-muted)' }}>
                          {enq.customizationText}
                        </span>
                      )}
                    </td>
                    <td style={{ fontSize: '0.85rem' }}>
                      <span style={{ display: 'block', fontWeight: 600 }}>{enq.customerName || 'Direct Visitor'}</span>
                      {enq.customerPhone && <span style={{ color: 'var(--color-text-muted)' }}>{enq.customerPhone}</span>}
                    </td>
                    <td>
                      <select
                        value={enq.status}
                        onChange={(e) => handleUpdateStatus(enq.id, e.target.value as any)}
                        style={{
                          fontSize: '0.8rem',
                          padding: '0.25rem 0.5rem',
                          borderRadius: 'var(--radius-sm)',
                          border: '1px solid var(--color-border)',
                          backgroundColor:
                            enq.status === 'Order Confirmed' ? '#E6EFE8' :
                            enq.status === 'In Discussion' ? '#FEF3C7' : '#FFFFFF',
                          color:
                            enq.status === 'Order Confirmed' ? 'var(--color-whatsapp)' :
                            enq.status === 'In Discussion' ? '#92400E' : 'var(--color-espresso)',
                          fontWeight: 600,
                        }}
                      >
                        <option value="New">New</option>
                        <option value="In Discussion">In Discussion</option>
                        <option value="Sample Dispatched">Sample Dispatched</option>
                        <option value="Order Confirmed">Order Confirmed</option>
                        <option value="Archived">Archived</option>
                      </select>
                    </td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--color-text-light)', whiteSpace: 'nowrap' }}>
                      {new Date(enq.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p style={{ textAlign: 'center', padding: '2rem', color: 'var(--color-text-muted)' }}>
            No customer enquiries recorded yet.
          </p>
        )}
      </div>
    </div>
  );
}
