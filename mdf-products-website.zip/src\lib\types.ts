export interface ProductDimensions {
  length: number;
  width: number;
  height: number;
  unit: 'mm' | 'cm';
}

export interface Product {
  id: string; // e.g., "MDF-BX-101"
  name: string;
  slug: string;
  category: string;
  price: number; // in INR
  priceUnit: string; // e.g. "per piece", "per set of 2"
  moq: number; // Minimum Order Quantity
  dimensions: ProductDimensions;
  mdfThickness: string; // e.g. "5.5mm High-Density MDF"
  material: string; // e.g. "Pine Wood MDF Board (Export Quality)"
  finishOptions: string[]; // e.g. ["Raw Sanded", "Melamine Coated", "Walnut Stained"]
  colorOptions: string[]; // e.g. ["Natural Beige", "Walnut Brown", "Ivory Matte"]
  customizationAvailable: boolean;
  featured: boolean;
  bestseller: boolean;
  isNew: boolean;
  published: boolean;
  images: string[];
  description: string;
  stockStatus: 'In Stock' | 'Made to Order' | 'Bulk Only';
  rating?: number;
  reviewsCount?: number;
  weightGrams?: number;
  laserDetailLevel?: 'Plain' | 'Intricate Cut' | 'Pre-Marked Outline' | '3D Layered';
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  order: number;
  productCount?: number;
}

export interface StoreSettings {
  storeName: string;
  logoUrl?: string;
  tagline: string;
  announcement: string;
  whatsappNumber: string; // e.g. "919876543210" without '+'
  displayPhone: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  gstin: string;
  workingHours: string;
  socialLinks: {
    instagram: string;
    facebook: string;
    pinterest: string;
    youtube?: string;
  };
  adminEmail: string;
  adminPasswordHash: string;
}

export interface CustomerEnquiry {
  id: string;
  productId: string;
  productName: string;
  productPrice: number;
  quantity: number;
  dimensions: string;
  material: string;
  finish: string;
  color?: string;
  customizationText?: string;
  customerName?: string;
  customerPhone?: string;
  customerCity?: string;
  status: 'New' | 'In Discussion' | 'Sample Dispatched' | 'Order Confirmed' | 'Archived';
  source: 'whatsapp_click' | 'custom_form' | 'bulk_form';
  createdAt: string;
  notes?: string;
}

export interface CustomQuoteRequest {
  id: string;
  name: string;
  phone: string;
  email?: string;
  city: string;
  category: string;
  dimensions: string;
  thickness: string;
  quantity: number;
  finish: string;
  details: string;
  referenceFileUrl?: string;
  createdAt: string;
  status: 'Pending' | 'Quoted' | 'Closed';
}
