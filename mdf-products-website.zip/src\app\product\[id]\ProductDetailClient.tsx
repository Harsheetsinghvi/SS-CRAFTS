'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import {
  MessageCircle,
  Ruler,
  Layers,
  Copy,
  Check,
  Shield,
  Truck,
  Sparkles,
  Share2
} from 'lucide-react';
import { Product } from '@/lib/types';
import { buildProductEnquiryMessage, generateWhatsAppLink } from '@/lib/whatsapp';

interface ProductDetailClientProps {
  product: Product;
  whatsappNumber: string;
}

export default function ProductDetailClient({ product, whatsappNumber }: ProductDetailClientProps) {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [dimensionUnit, setDimensionUnit] = useState<'mm' | 'cm'>('mm');
  const [selectedFinish, setSelectedFinish] = useState(product.finishOptions[0] || 'Raw Sanded');
  const [selectedColor, setSelectedColor] = useState(product.colorOptions[0] || 'Natural Blonde');
  const [quantity, setQuantity] = useState(product.moq || 10);
  const [customDimensions, setCustomDimensions] = useState('');
  const [customNotes, setCustomNotes] = useState('');
  const [copied, setCopied] = useState(false);

  const { length, width, height } = product.dimensions;
  const isCm = dimensionUnit === 'cm';
  const displayLength = isCm ? (length / 10).toFixed(1) : length;
  const displayWidth = isCm ? (width / 10).toFixed(1) : width;
  const displayHeight = isCm ? (height / 10).toFixed(1) : height;

  const message = buildProductEnquiryMessage({
    product,
    quantity,
    finish: selectedFinish,
    color: selectedColor,
    customizationRequired: customNotes || (customDimensions ? `Custom Sizing: ${customDimensions}` : 'None (Standard catalogue design)'),
    customDimensions: customDimensions || undefined,
  });

  const whatsappUrl = generateWhatsAppLink(whatsappNumber, message);

  const handleWhatsAppEnquiry = async () => {
    try {
      await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          productName: product.name,
          productPrice: product.price,
          quantity,
          dimensions: customDimensions || `${length}x${width}x${height} mm`,
          material: product.material,
          finish: selectedFinish,
          color: selectedColor,
          customizationText: customNotes,
          source: 'whatsapp_click',
        }),
      });
    } catch (e) {}
  };

  const handleCopySpecs = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const images = product.images && product.images.length > 0 ? product.images : [
    'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80'
  ];

  return (
    <div
      style={{
        backgroundColor: '#FFFFFF',
        borderRadius: 'var(--radius-lg)',
        border: '1px solid var(--color-border)',
        boxShadow: 'var(--shadow-card)',
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(340px, 1fr))',
        }}
      >
        {/* Left: Product Media Gallery */}
        <div
          style={{
            padding: '2.5rem',
            backgroundColor: 'var(--color-warm-ivory)',
            borderRight: '1px solid var(--color-border)',
            display: 'flex',
            flexDirection: 'column',
            gap: '1.5rem',
          }}
        >
          <div
            style={{
              position: 'relative',
              width: '100%',
              paddingTop: '85%',
              borderRadius: 'var(--radius-md)',
              overflow: 'hidden',
              backgroundColor: '#FFFFFF',
              boxShadow: 'var(--shadow-sm)',
            }}
          >
            <Image
              src={images[activeImageIndex] || images[0]}
              alt={product.name}
              fill
              priority
              style={{ objectFit: 'cover' }}
            />
          </div>

          {images.length > 1 && (
            <div style={{ display: 'flex', gap: '0.75rem', overflowX: 'auto', paddingBottom: '0.25rem' }}>
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  style={{
                    position: 'relative',
                    width: '75px',
                    height: '75px',
                    flexShrink: 0,
                    borderRadius: 'var(--radius-sm)',
                    overflow: 'hidden',
                    border: activeImageIndex === idx ? '2px solid var(--color-walnut-brown)' : '1px solid var(--color-border)',
                    opacity: activeImageIndex === idx ? 1 : 0.65,
                  }}
                >
                  <Image src={img} alt={`View ${idx + 1}`} fill style={{ objectFit: 'cover' }} />
                </button>
              ))}
            </div>
          )}

          {/* Quality highlights */}
          <div
            style={{
              backgroundColor: '#FFFFFF',
              borderRadius: 'var(--radius-md)',
              padding: '1.25rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.75rem',
              fontSize: '0.85rem',
              color: 'var(--color-text-muted)',
              border: '1px solid var(--color-border-subtle)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <Shield size={18} style={{ color: 'var(--color-whatsapp)' }} />
              <span>Moisture Resistant Pine MDF Board (Export Certified)</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <Truck size={18} style={{ color: 'var(--color-walnut-brown)' }} />
              <span>Safe Wooden Crate & Multi-layer Bubble Wrap Packing</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <Sparkles size={18} style={{ color: 'var(--color-caramel)' }} />
              <span>Precision Optical Laser Cutting (0.1mm Accuracy)</span>
            </div>
          </div>
        </div>

        {/* Right: Product Specifications & WhatsApp Enquirer */}
        <div style={{ padding: '2.5rem', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <span className="badge badge-custom">{product.category}</span>
              <span style={{ fontSize: '0.8rem', color: 'var(--color-text-light)', fontFamily: 'monospace' }}>
                SKU: {product.id}
              </span>
            </div>

            <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '2rem', lineHeight: 1.25, color: 'var(--color-espresso)' }}>
              {product.name}
            </h1>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.6rem', marginTop: '0.85rem' }}>
              <span style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
                ₹{product.price}
              </span>
              <span style={{ fontSize: '0.95rem', color: 'var(--color-text-muted)' }}>
                {product.priceUnit || 'per piece'}
              </span>
              <span style={{ marginLeft: 'auto', fontSize: '0.85rem', color: 'var(--color-whatsapp)', fontWeight: 600 }}>
                ● {product.stockStatus}
              </span>
            </div>
          </div>

          <p style={{ fontSize: '0.95rem', color: 'var(--color-text-muted)', lineHeight: 1.65 }}>
            {product.description}
          </p>

          {/* Dimensions Box */}
          <div
            style={{
              backgroundColor: 'var(--color-warm-ivory)',
              padding: '1.25rem',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--color-border)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
              <span style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--color-espresso)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <Ruler size={16} /> Dimensions & Specifications
              </span>
              <div style={{ display: 'flex', gap: '0.3rem', backgroundColor: '#FFFFFF', padding: '0.15rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border-subtle)' }}>
                <button
                  onClick={() => setDimensionUnit('mm')}
                  style={{
                    padding: '0.2rem 0.6rem',
                    fontSize: '0.75rem',
                    fontWeight: 600,
                    borderRadius: '4px',
                    backgroundColor: dimensionUnit === 'mm' ? 'var(--color-espresso)' : 'transparent',
                    color: dimensionUnit === 'mm' ? '#FFFFFF' : 'var(--color-espresso)',
                  }}
                >
                  mm
                </button>
                <button
                  onClick={() => setDimensionUnit('cm')}
                  style={{
                    padding: '0.2rem 0.6rem',
                    fontSize: '0.75rem',
                    fontWeight: 600,
                    borderRadius: '4px',
                    backgroundColor: dimensionUnit === 'cm' ? 'var(--color-espresso)' : 'transparent',
                    color: dimensionUnit === 'cm' ? '#FFFFFF' : 'var(--color-espresso)',
                  }}
                >
                  cm
                </button>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.6rem', textAlign: 'center' }}>
              <div style={{ background: '#FFFFFF', padding: '0.6rem', borderRadius: '6px' }}>
                <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', display: 'block' }}>Length</span>
                <strong>{displayLength} {dimensionUnit}</strong>
              </div>
              <div style={{ background: '#FFFFFF', padding: '0.6rem', borderRadius: '6px' }}>
                <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', display: 'block' }}>Width</span>
                <strong>{displayWidth} {dimensionUnit}</strong>
              </div>
              <div style={{ background: '#FFFFFF', padding: '0.6rem', borderRadius: '6px' }}>
                <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', display: 'block' }}>Height</span>
                <strong>{displayHeight} {dimensionUnit}</strong>
              </div>
            </div>

            <div style={{ marginTop: '0.75rem', fontSize: '0.85rem', color: 'var(--color-text-muted)', display: 'flex', justifyContent: 'space-between' }}>
              <span>MDF Thickness: <strong>{product.mdfThickness}</strong></span>
              <span>Material: <strong>{product.material}</strong></span>
            </div>
          </div>

          {/* Options: Finish & Color */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
            <div>
              <label className="form-label">Material Finish</label>
              <select
                value={selectedFinish}
                onChange={(e) => setSelectedFinish(e.target.value)}
                className="form-select"
              >
                {product.finishOptions.map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="form-label">Color / Stain</label>
              <select
                value={selectedColor}
                onChange={(e) => setSelectedColor(e.target.value)}
                className="form-select"
              >
                {product.colorOptions.map((col) => (
                  <option key={col} value={col}>{col}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Customizer Notes */}
          {product.customizationAvailable && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.5fr', gap: '1rem' }}>
              <div>
                <label className="form-label">Custom Dimensions (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. 280x210x85 mm"
                  value={customDimensions}
                  onChange={(e) => setCustomDimensions(e.target.value)}
                  className="form-input"
                />
              </div>
              <div>
                <label className="form-label">Branding / Monogram Notes</label>
                <input
                  type="text"
                  placeholder="e.g. Laser engrave logo, acrylic lid"
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  className="form-input"
                />
              </div>
            </div>
          )}

          {/* Quantity & Estimated Total */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: '1rem 1.25rem',
              backgroundColor: 'var(--color-warm-ivory)',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--color-border)',
            }}
          >
            <div>
              <span style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)', display: 'block' }}>
                Order Quantity (MOQ: {product.moq} pcs)
              </span>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginTop: '0.35rem' }}>
                <button
                  onClick={() => setQuantity(Math.max(product.moq || 1, quantity - 5))}
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid var(--color-border)',
                    fontWeight: 700,
                  }}
                >
                  -
                </button>
                <input
                  type="number"
                  min={product.moq || 1}
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  style={{
                    width: '70px',
                    textAlign: 'center',
                    fontWeight: 700,
                    border: '1px solid var(--color-border-subtle)',
                    borderRadius: '6px',
                    padding: '0.35rem',
                  }}
                />
                <button
                  onClick={() => setQuantity(quantity + 5)}
                  style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '50%',
                    backgroundColor: '#FFFFFF',
                    border: '1px solid var(--color-border)',
                    fontWeight: 700,
                  }}
                >
                  +
                </button>
              </div>
            </div>

            <div style={{ textAlign: 'right' }}>
              <span style={{ fontSize: '0.82rem', color: 'var(--color-text-light)', display: 'block' }}>
                Estimated Batch Total
              </span>
              <span style={{ fontSize: '1.45rem', fontWeight: 700, color: 'var(--color-espresso)' }}>
                ₹{(product.price * quantity).toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Action CTAs */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleWhatsAppEnquiry}
              className="btn btn-whatsapp btn-lg"
              style={{ width: '100%', justifyContent: 'center' }}
            >
              <MessageCircle size={22} />
              <span>Enquire on WhatsApp</span>
            </a>

            <div style={{ display: 'flex', gap: '0.75rem' }}>
              <button
                onClick={handleCopySpecs}
                className="btn btn-secondary btn-sm"
                style={{ flex: 1, justifyContent: 'center' }}
              >
                {copied ? <Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> : <Copy size={16} />}
                <span>{copied ? 'Enquiry Message Copied!' : 'Copy Enquiry Message'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
