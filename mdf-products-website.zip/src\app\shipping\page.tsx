import React from 'react';
import { Truck, ShieldCheck, Clock, PackageCheck, AlertCircle } from 'lucide-react';

export const metadata = {
  title: 'Shipping & Delivery Policy | SS Crafts',
  description: 'Learn about our Pan-India crate packing standards, dispatch timelines, and delivery options for MDF products.',
};

export default function ShippingPage() {
  return (
    <div style={{ backgroundColor: 'var(--color-warm-ivory)', padding: '4rem 0 6rem' }}>
      <div className="container" style={{ maxWidth: '840px' }}>
        <h1 className="display-title" style={{ fontSize: '2.4rem', marginBottom: '1rem' }}>
          Shipping & Delivery Policy
        </h1>
        <p style={{ fontSize: '1rem', color: 'var(--color-text-muted)', marginBottom: '2.5rem' }}>
          Safe Crate Logistics Across India
        </p>

        <div style={{ backgroundColor: '#FFFFFF', padding: '2.5rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-card)', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              1. Dispatch Timelines
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              <strong>Standard Catalogue Products:</strong> Ready stock items are dispatched within 24 to 48 hours from our factory.
              <br />
              <strong>Custom Laser Cutting & Engraved Hampers:</strong> Custom fabrication requires 3 to 6 business days depending on order volume and prototype approvals.
            </p>
          </div>

          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              2. Packaging & Damage Protection
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              Because precision laser cut products feature delicate jali fretwork, every order is safeguarded using:
            </p>
            <ul style={{ paddingLeft: '1.5rem', fontSize: '0.9rem', color: 'var(--color-text-muted)', marginTop: '0.5rem', lineHeight: 1.6 }}>
              <li>Individual bubble-wrap sleeves for every box lid and frame.</li>
              <li>High-impact plastic corner protectors on serving trays and larger hampers.</li>
              <li>Heavy-duty 5-ply export corrugated cartons or wooden crates for bulk pallets.</li>
            </ul>
          </div>

          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              3. Courier Partners & Tracking
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              We partner with trusted express carriers including BlueDart, Delhivery, DTDC, and VRL Logistics for heavy freight shipments. Tracking IDs are shared directly over WhatsApp and email as soon as the consignment is picked up.
            </p>
          </div>

          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              4. Damaged or Discrepant Shipments
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              In the unlikely event of courier transit damage, please record an unboxing video and send photos to our WhatsApp support (+91 93132 29609) within 48 hours of receipt. We will promptly dispatch free replacements or issue a credit note.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
