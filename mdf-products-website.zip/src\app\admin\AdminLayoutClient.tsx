'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard,
  Box,
  Layers,
  MessageCircle,
  Settings,
  LogOut,
  ExternalLink,
  ShieldCheck,
  ChevronRight,
  Menu,
  X
} from 'lucide-react';

interface AdminLayoutClientProps {
  children: React.ReactNode;
}

export default function AdminLayoutClient({ children }: AdminLayoutClientProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [adminEmail, setAdminEmail] = useState('');

  // If on login page, render children directly without admin layout chrome
  const isLoginPage = pathname === '/admin/login';

  useEffect(() => {
    if (isLoginPage) {
      setLoading(false);
      return;
    }

    // Check session
    fetch('/api/admin/me')
      .then((res) => {
        if (!res.ok) {
          router.push('/admin/login');
        } else {
          return res.json();
        }
      })
      .then((data) => {
        if (data?.authenticated) {
          setAdminEmail(data.admin.email);
          setLoading(false);
        }
      })
      .catch(() => {
        router.push('/admin/login');
      });
  }, [pathname, isLoginPage, router]);

  const handleLogout = async () => {
    try {
      await fetch('/api/admin/logout', { method: 'POST' });
      localStorage.removeItem('mdf_admin_token');
      router.push('/admin/login');
    } catch (e) {
      router.push('/admin/login');
    }
  };

  if (isLoginPage) {
    return <>{children}</>;
  }

  if (loading) {
    return (
      <div style={{ minHeight: '80vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <p style={{ fontFamily: 'var(--font-heading)', fontSize: '1.2rem', color: 'var(--color-espresso)' }}>
          Verifying Admin Credentials...
        </p>
      </div>
    );
  }

  const menuItems = [
    { name: 'Dashboard', href: '/admin/dashboard', icon: <LayoutDashboard size={18} /> },
    { name: 'Products', href: '/admin/products', icon: <Box size={18} /> },
    { name: 'Categories', href: '/admin/categories', icon: <Layers size={18} /> },
    { name: 'Enquiries & Leads', href: '/admin/enquiries', icon: <MessageCircle size={18} /> },
    { name: 'Store & WhatsApp', href: '/admin/settings', icon: <Settings size={18} /> },
  ];

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#F4EFE6', display: 'flex', flexDirection: 'column' }}>
      {/* Admin Top Navigation */}
      <header
        style={{
          backgroundColor: 'var(--color-espresso)',
          color: '#FFFFFF',
          padding: '0.85rem 1.5rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          borderBottom: '2px solid var(--color-walnut-brown)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
          <button
            onClick={() => setMobileSidebarOpen(!mobileSidebarOpen)}
            className="mobile-admin-toggle"
            style={{ color: '#FFFFFF', display: 'none' }}
          >
            {mobileSidebarOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div
              style={{
                width: '36px',
                height: '36px',
                backgroundColor: '#FFFFFF',
                borderRadius: '50%',
                overflow: 'hidden',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                border: '1.5px solid var(--color-caramel)',
                flexShrink: 0,
              }}
            >
              <Image src="/logo.png" alt="SS Crafts Logo" width={36} height={36} style={{ objectFit: 'contain' }} />
            </div>
            <div>
              <span style={{ fontWeight: 700, fontSize: '1.05rem', letterSpacing: '-0.01em', display: 'block', lineHeight: 1.1 }}>
                SS Crafts Admin
              </span>
              <span style={{ fontSize: '0.7rem', color: 'var(--color-caramel)' }}>Catalogue Manager</span>
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
          <Link
            href="/"
            target="_blank"
            style={{
              fontSize: '0.82rem',
              color: 'var(--color-sand-beige)',
              display: 'flex',
              alignItems: 'center',
              gap: '0.35rem',
            }}
          >
            <span>Live Website</span>
            <ExternalLink size={14} />
          </Link>

          <span style={{ fontSize: '0.82rem', color: '#A99D91' }} className="admin-email-badge">
            {adminEmail}
          </span>

          <button
            onClick={handleLogout}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.35rem',
              fontSize: '0.82rem',
              color: '#F87171',
              padding: '0.35rem 0.65rem',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid rgba(248, 113, 113, 0.3)',
            }}
          >
            <LogOut size={14} />
            <span>Logout</span>
          </button>
        </div>
      </header>

      {/* Main Admin Workspace */}
      <div style={{ display: 'flex', flex: 1 }}>
        {/* Admin Sidebar Navigation */}
        <aside
          className={`admin-sidebar ${mobileSidebarOpen ? 'open' : ''}`}
          style={{
            width: '250px',
            backgroundColor: '#FFFFFF',
            borderRight: '1px solid var(--color-border)',
            padding: '1.5rem 1rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.5rem',
          }}
        >
          {menuItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={() => setMobileSidebarOpen(false)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.75rem',
                  padding: '0.75rem 1rem',
                  borderRadius: 'var(--radius-md)',
                  fontSize: '0.92rem',
                  fontWeight: isActive ? 700 : 500,
                  backgroundColor: isActive ? 'var(--color-warm-ivory)' : 'transparent',
                  color: isActive ? 'var(--color-walnut-brown)' : 'var(--color-espresso)',
                  transition: 'var(--transition)',
                }}
              >
                <div style={{ color: isActive ? 'var(--color-walnut-brown)' : 'var(--color-text-light)' }}>
                  {item.icon}
                </div>
                <span>{item.name}</span>
                {isActive && <ChevronRight size={16} style={{ marginLeft: 'auto', color: 'var(--color-walnut-brown)' }} />}
              </Link>
            );
          })}
        </aside>

        {/* Content View Area */}
        <main style={{ flex: 1, padding: '2rem', overflowX: 'auto' }}>
          {children}
        </main>
      </div>

      <style jsx>{`
        @media (max-width: 768px) {
          .admin-sidebar {
            display: none !important;
            position: fixed;
            top: 56px;
            bottom: 0;
            left: 0;
            z-index: 999;
            box-shadow: var(--shadow-lg);
          }
          .admin-sidebar.open {
            display: flex !important;
          }
          .mobile-admin-toggle {
            display: block !important;
          }
          .admin-email-badge {
            display: none;
          }
        }
      `}</style>
    </div>
  );
}
