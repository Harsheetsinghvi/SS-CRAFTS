'use client';

import React, { useState } from 'react';
import { Building2, MessageCircle, Gift, Check, Send, Sparkles } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

interface BulkGiftingProps {
  whatsappNumber: string;
}

export default function BulkGiftingSection({ whatsappNumber }: BulkGiftingProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    company: '',
    quantity: '100',
    occasion: 'Corporate Diwali Gifting',
    notes: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const cleanPhone = sanitizeWhatsAppNumber(whatsappNumber);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await fetch('/api/custom-quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: formData.name,
          phone: formData.phone,
          details: `Company: ${formData.company || 'N/A'}, Occasion: ${formData.occasion}, Notes: ${formData.notes}`,
          quantity: Number(formData.quantity) || 100,
          category: 'Corporate & Bulk Order',
        }),
      });

      setSubmitted(true);

      // Also generate direct WhatsApp redirection
      const msg = [
        'Hello SS Crafts,',
        `My name is ${formData.name}${formData.company ? ` from ${formData.company}` : ''}.`,
        `I am requesting a bulk corporate / event quotation for ${formData.quantity} units.`,
        `Occasion/Purpose: ${formData.occasion}`,
        formData.notes ? `Requirement: ${formData.notes}` : '',
        'Please share your corporate catalogue and quantity-tiered pricing.',
      ].filter(Boolean).join('\n');

      const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
      window.open(waUrl, '_blank');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section style={{ padding: '5.5rem 0', backgroundColor: 'var(--color-cream-white)' }}>
      <div className="container">
        <div
          style={{
            backgroundColor: 'var(--color-espresso)',
            borderRadius: '24px',
            color: 'var(--color-sand-beige)',
            padding: '3.5rem 2.5rem',
            overflow: 'hidden',
            position: 'relative',
          }}
        >
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
              gap: '3rem',
              alignItems: 'center',
            }}
          >
            {/* Left Column */}
            <div>
              <div
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                  backgroundColor: 'rgba(184, 137, 99, 0.2)',
                  color: 'var(--color-caramel)',
                  padding: '0.35rem 0.9rem',
                  borderRadius: 'var(--radius-pill)',
                  fontSize: '0.8rem',
                  fontWeight: 700,
                  marginBottom: '1rem',
                  letterSpacing: '0.06em',
                  textTransform: 'uppercase',
                }}
              >
                <Building2 size={16} /> Corporate & Event Hampers
              </div>

              <h2
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: 'clamp(1.8rem, 3.5vw, 2.5rem)',
                  color: '#FFFFFF',
                  marginBottom: '1rem',
                  lineHeight: 1.2,
                }}
              >
                Elevate Corporate & Wedding Gifting
              </h2>

              <p style={{ fontSize: '1rem', color: '#D4C9BC', lineHeight: 1.65, marginBottom: '2rem' }}>
                We partner with corporate procurement teams, wedding curators, gourmet chocolatiers, and artisan brands across India to produce high-finish branded packaging.
              </p>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                  <div style={{ color: 'var(--color-whatsapp-bright)' }}><Check size={18} /></div>
                  <span style={{ fontSize: '0.92rem' }}>Company logo engraving & UV colour printing available</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                  <div style={{ color: 'var(--color-whatsapp-bright)' }}><Check size={18} /></div>
                  <span style={{ fontSize: '0.92rem' }}>Volume tiered discounts for orders above 100, 250, and 1000+ units</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                  <div style={{ color: 'var(--color-whatsapp-bright)' }}><Check size={18} /></div>
                  <span style={{ fontSize: '0.92rem' }}>Safe palletised freight shipping with GST e-way bills</span>
                </div>
              </div>
            </div>

            {/* Right Column: Form */}
            <div
              style={{
                backgroundColor: 'var(--color-cream-white)',
                color: 'var(--color-espresso)',
                borderRadius: 'var(--radius-lg)',
                padding: '2rem',
                boxShadow: 'var(--shadow-lg)',
              }}
            >
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.4rem' }}>
                Request Corporate Quotation
              </h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem' }}>
                Submit below to receive pricing and connect directly on WhatsApp.
              </p>

              {submitted ? (
                <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
                  <div
                    style={{
                      width: '50px',
                      height: '50px',
                      borderRadius: '50%',
                      backgroundColor: '#E6EFE8',
                      color: 'var(--color-whatsapp)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      margin: '0 auto 1rem',
                    }}
                  >
                    <Check size={26} />
                  </div>
                  <h4 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', marginBottom: '0.5rem' }}>
                    Quotation Request Sent!
                  </h4>
                  <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginBottom: '1.2rem' }}>
                    We have recorded your details and opened WhatsApp for instant catalog sharing.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="btn btn-secondary btn-sm"
                  >
                    Submit Another Requirement
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.9rem' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                    <div>
                      <label className="form-label" style={{ fontSize: '0.8rem' }}>Contact Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="Your full name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="form-input"
                        style={{ padding: '0.6rem' }}
                      />
                    </div>
                    <div>
                      <label className="form-label" style={{ fontSize: '0.8rem' }}>WhatsApp / Phone *</label>
                      <input
                        type="tel"
                        required
                        placeholder="10-digit number"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="form-input"
                        style={{ padding: '0.6rem' }}
                      />
                    </div>
                  </div>

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
                    <div>
                      <label className="form-label" style={{ fontSize: '0.8rem' }}>Company / Brand</label>
                      <input
                        type="text"
                        placeholder="Company or Studio"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        className="form-input"
                        style={{ padding: '0.6rem' }}
                      />
                    </div>
                    <div>
                      <label className="form-label" style={{ fontSize: '0.8rem' }}>Est. Quantity</label>
                      <select
                        value={formData.quantity}
                        onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                        className="form-select"
                        style={{ padding: '0.6rem' }}
                      >
                        <option value="50">50 - 100 units</option>
                        <option value="250">100 - 250 units</option>
                        <option value="500">250 - 500 units</option>
                        <option value="1000">500 - 1,000 units</option>
                        <option value="2500">1,000+ units (Wholesale)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="form-label" style={{ fontSize: '0.8rem' }}>Occasion / Purpose</label>
                    <select
                      value={formData.occasion}
                      onChange={(e) => setFormData({ ...formData, occasion: e.target.value })}
                      className="form-select"
                      style={{ padding: '0.6rem' }}
                    >
                      <option value="Corporate Diwali Gifting">Corporate Diwali & Festive Hampers</option>
                      <option value="Employee Onboarding Kits">Employee Welcome & Executive Kits</option>
                      <option value="Luxury Wedding Trousseau">Luxury Wedding Trousseau & Favours</option>
                      <option value="Art & Craft Workshop Supplies">Art & Craft Workshop Blank Bases</option>
                      <option value="Gourmet Food Packaging">Gourmet Food / Tea / Bakery Packaging</option>
                    </select>
                  </div>

                  <div>
                    <label className="form-label" style={{ fontSize: '0.8rem' }}>Specific Requirements</label>
                    <textarea
                      rows={2}
                      placeholder="Share dimensions, box style, or logo requirements..."
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      className="form-textarea"
                      style={{ padding: '0.6rem', minHeight: '65px' }}
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="btn btn-whatsapp btn-lg"
                    style={{ width: '100%', justifyContent: 'center', marginTop: '0.3rem' }}
                  >
                    <MessageCircle size={18} />
                    <span>{loading ? 'Processing...' : 'Submit & Connect on WhatsApp'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
