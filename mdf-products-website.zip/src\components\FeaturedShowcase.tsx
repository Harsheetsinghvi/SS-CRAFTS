'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ArrowRight, Sparkles, Flame, Star, Layers } from 'lucide-react';
import { Product } from '@/lib/types';
import ProductCard from './ProductCard';
import ProductModal from './ProductModal';

interface FeaturedShowcaseProps {
  products: Product[];
  whatsappNumber: string;
}

export default function FeaturedShowcase({ products, whatsappNumber }: FeaturedShowcaseProps) {
  const [activeTab, setActiveTab] = useState<'bestseller' | 'featured' | 'new'>('bestseller');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = products.filter((p) => {
    if (activeTab === 'bestseller') return p.bestseller;
    if (activeTab === 'new') return p.isNew;
    return p.featured;
  }).slice(0, 8); // Top 8 items

  return (
    <section style={{ padding: '5.5rem 0', backgroundColor: 'var(--color-warm-ivory)' }}>
      <div className="container">
        {/* Section Header */}
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'flex-end',
            justifyContent: 'space-between',
            gap: '1.5rem',
            marginBottom: '3rem',
          }}
        >
          <div>
            <span
              style={{
                fontSize: '0.8rem',
                letterSpacing: '0.12em',
                textTransform: 'uppercase',
                color: 'var(--color-walnut-brown)',
                fontWeight: 700,
                display: 'block',
                marginBottom: '0.4rem',
              }}
            >
              Handcrafted Highlights
            </span>
            <h2 className="section-title" style={{ margin: 0 }}>
              Featured & Bestselling Products
            </h2>
          </div>

          {/* Interactive Filter Pills */}
          <div
            style={{
              display: 'flex',
              gap: '0.5rem',
              backgroundColor: 'var(--color-cream-white)',
              padding: '0.3rem',
              borderRadius: 'var(--radius-pill)',
              border: '1px solid var(--color-border)',
            }}
          >
            <button
              onClick={() => setActiveTab('bestseller')}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                padding: '0.55rem 1.1rem',
                borderRadius: 'var(--radius-pill)',
                fontSize: '0.85rem',
                fontWeight: 600,
                backgroundColor: activeTab === 'bestseller' ? 'var(--color-espresso)' : 'transparent',
                color: activeTab === 'bestseller' ? '#FFFFFF' : 'var(--color-espresso)',
                transition: 'var(--transition)',
              }}
            >
              <Flame size={15} style={{ color: activeTab === 'bestseller' ? '#F4A261' : 'inherit' }} />
              <span>Bestsellers</span>
            </button>

            <button
              onClick={() => setActiveTab('featured')}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                padding: '0.55rem 1.1rem',
                borderRadius: 'var(--radius-pill)',
                fontSize: '0.85rem',
                fontWeight: 600,
                backgroundColor: activeTab === 'featured' ? 'var(--color-espresso)' : 'transparent',
                color: activeTab === 'featured' ? '#FFFFFF' : 'var(--color-espresso)',
                transition: 'var(--transition)',
              }}
            >
              <Star size={15} style={{ color: activeTab === 'featured' ? '#F4A261' : 'inherit' }} />
              <span>Staff Picks</span>
            </button>

            <button
              onClick={() => setActiveTab('new')}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.35rem',
                padding: '0.55rem 1.1rem',
                borderRadius: 'var(--radius-pill)',
                fontSize: '0.85rem',
                fontWeight: 600,
                backgroundColor: activeTab === 'new' ? 'var(--color-espresso)' : 'transparent',
                color: activeTab === 'new' ? '#FFFFFF' : 'var(--color-espresso)',
                transition: 'var(--transition)',
              }}
            >
              <Sparkles size={15} style={{ color: activeTab === 'new' ? '#A3D9A5' : 'inherit' }} />
              <span>New Arrivals</span>
            </button>
          </div>
        </div>

        {/* Product Cards Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: '2rem',
          }}
        >
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              whatsappNumber={whatsappNumber}
              onViewDetails={(p) => setSelectedProduct(p)}
            />
          ))}
        </div>

        {/* View Entire Catalogue CTA */}
        <div style={{ textAlign: 'center', marginTop: '3.5rem' }}>
          <Link href="/catalogue" className="btn btn-secondary btn-lg">
            <span>View Complete Catalogue ({products.length} Products)</span>
            <ArrowRight size={18} />
          </Link>
        </div>
      </div>

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          whatsappNumber={whatsappNumber}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </section>
  );
}
