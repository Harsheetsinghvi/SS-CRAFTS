import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { MessageCircle, Mail, Phone, MapPin, Box, ArrowUpRight } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

interface FooterProps {
  settings?: {
    storeName?: string;
    tagline?: string;
    whatsappNumber?: string;
    displayPhone?: string;
    email?: string;
    address?: string;
    city?: string;
    state?: string;
    pincode?: string;
    gstin?: string;
  };
}

export default function Footer({ settings }: FooterProps) {
  const whatsappNum = settings?.whatsappNumber || '919313229609';
  const cleanPhone = sanitizeWhatsAppNumber(whatsappNum);

  return (
    <footer
      style={{
        backgroundColor: 'var(--color-espresso)',
        color: 'var(--color-sand-beige)',
        padding: '4.5rem 0 2rem',
        borderTop: '3px solid var(--color-walnut-brown)',
      }}
    >
      <div className="container">
        {/* Main Footer Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '3rem',
            marginBottom: '3.5rem',
          }}
        >
          {/* Column 1: Brand & Tagline */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.2rem' }}>
              <div
                style={{
                  width: '46px',
                  height: '46px',
                  backgroundColor: '#FFFFFF',
                  borderRadius: '50%',
                  overflow: 'hidden',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.25)',
                  border: '1.5px solid var(--color-walnut-brown)',
                  flexShrink: 0,
                }}
              >
                <Image
                  src="/logo.png"
                  alt="SS Crafts Logo"
                  width={46}
                  height={46}
                  style={{ objectFit: 'contain', width: '100%', height: '100%' }}
                />
              </div>
              <div>
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: '1.4rem',
                    color: '#FFFFFF',
                    margin: 0,
                    lineHeight: 1.1,
                  }}
                >
                  {settings?.storeName || 'SS Crafts'}
                </h3>
                <span style={{ fontSize: '0.72rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--color-caramel)' }}>
                  MDF Studio &bull; Craftsmanship
                </span>
              </div>
            </div>

            <p style={{ fontSize: '0.92rem', color: '#D4C9BC', lineHeight: 1.6, marginBottom: '1.5rem' }}>
              {settings?.tagline || 'Crafting Ideas Into Beautiful MDF Products.'} Premium manufacturer of high-density MDF piggy banks, Diwali & Rakshabandhan boxes, luxury hamper boxes, phone stands, awards, drawing colour sheets, MDF games, and custom cake toppers.
            </p>

            <a
              href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent('Hello SS Crafts! I would like to enquire about your MDF products and customization options.')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-whatsapp btn-sm"
              style={{ width: 'fit-content' }}
            >
              <MessageCircle size={16} /> Instant WhatsApp Contact
            </a>
          </div>

          {/* Column 2: Popular Categories */}
          <div>
            <h4
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: '1.15rem',
                color: '#FFFFFF',
                marginBottom: '1.2rem',
                borderBottom: '1px solid rgba(232, 222, 208, 0.15)',
                paddingBottom: '0.5rem',
              }}
            >
              Product Categories
            </h4>
            <ul style={{ listStyle: 'none', display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '0.5rem 1rem', fontSize: '0.88rem' }}>
              <li>
                <Link href="/catalogue?category=Piggy+Banks" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Piggy Banks
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Diwali+Boxes" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Diwali Boxes
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Rakshabandhan+Boxes" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Rakshabandhan Box
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Hamper+Boxes" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Hamper Boxes
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Phone+Stands" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Phone Stands
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Boxes" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  MDF Boxes
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Awards+%26+Trophies" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Awards & Plaques
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Drawing+Sheets+for+Colour" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Drawing Sheets
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=MDF+Games" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  MDF Games
                </Link>
              </li>
              <li>
                <Link href="/catalogue?category=Cake+Toppers" style={{ color: '#D4C9BC', transition: 'var(--transition)' }}>
                  Cake Toppers
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Quick Navigation & Services */}
          <div>
            <h4
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: '1.15rem',
                color: '#FFFFFF',
                marginBottom: '1.2rem',
                borderBottom: '1px solid rgba(232, 222, 208, 0.15)',
                paddingBottom: '0.5rem',
              }}
            >
              Services & Policies
            </h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.6rem', fontSize: '0.9rem' }}>
              <li>
                <Link href="/custom-orders" style={{ color: '#D4C9BC', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                  Custom Sizing & Laser Cutting <ArrowUpRight size={14} />
                </Link>
              </li>
              <li>
                <Link href="/bulk-gifting" style={{ color: '#D4C9BC', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
                  Bulk Orders & Corporate Gifting <ArrowUpRight size={14} />
                </Link>
              </li>
              <li>
                <Link href="/shipping" style={{ color: '#D4C9BC' }}>
                  Shipping & Delivery Timeline
                </Link>
              </li>
              <li>
                <Link href="/privacy" style={{ color: '#D4C9BC' }}>
                  Privacy & Data Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" style={{ color: '#D4C9BC' }}>
                  Terms of Service & Care Guide
                </Link>
              </li>
              <li>
                <Link href="/admin/login" style={{ color: 'var(--color-caramel)' }}>
                  Admin Management Portal
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Factory & Contact Details */}
          <div>
            <h4
              style={{
                fontFamily: 'var(--font-heading)',
                fontSize: '1.15rem',
                color: '#FFFFFF',
                marginBottom: '1.2rem',
                borderBottom: '1px solid rgba(232, 222, 208, 0.15)',
                paddingBottom: '0.5rem',
              }}
            >
              Workshop & Contact
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem', fontSize: '0.9rem', color: '#D4C9BC' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.6rem' }}>
                <MapPin size={18} style={{ color: 'var(--color-caramel)', marginTop: '0.2rem', flexShrink: 0 }} />
                <span>
                  {settings?.address || 'Craftsman Industrial Hub'}, {settings?.city || 'Ahmedabad'}, {settings?.state || 'Gujarat'} - {settings?.pincode || '382445'}, India
                </span>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <Phone size={16} style={{ color: 'var(--color-caramel)', flexShrink: 0 }} />
                <a href={`tel:${settings?.displayPhone || '+919313229609'}`} style={{ color: '#D4C9BC' }}>
                  {settings?.displayPhone || '+91 93132 29609'}
                </a>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
                <Mail size={16} style={{ color: 'var(--color-caramel)', flexShrink: 0 }} />
                <a href={`mailto:${settings?.email || 'sscrafts104@gmail.com'}`} style={{ color: '#D4C9BC' }}>
                  {settings?.email || 'sscrafts104@gmail.com'}
                </a>
              </div>

              {settings?.gstin && (
                <div style={{ marginTop: '0.3rem', fontSize: '0.78rem', color: '#B88963' }}>
                  GSTIN: <strong>{settings.gstin}</strong> (Registered MSME)
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Bottom Bar with Copyright */}
        <div
          style={{
            borderTop: '1px solid rgba(232, 222, 208, 0.12)',
            paddingTop: '1.8rem',
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
            fontSize: '0.82rem',
            color: '#A99D91',
          }}
        >
          <div>
            &copy; {new Date().getFullYear()} {settings?.storeName || 'SS Crafts'}. All rights reserved. Handcrafted in India.
          </div>
          <div>
            Notice: All catalogue specifications are customizable. Enquire directly on WhatsApp for customized bulk quotes.
          </div>
        </div>
      </div>
    </footer>
  );
}
