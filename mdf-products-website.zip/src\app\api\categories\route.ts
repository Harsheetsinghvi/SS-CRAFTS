import { NextRequest, NextResponse } from 'next/server';
import { getAllCategories, saveCategory } from '@/lib/db';
import { checkAdminAuth } from '@/lib/auth';
import { Category } from '@/lib/types';

export async function GET() {
  try {
    const categories = getAllCategories();
    return NextResponse.json({ success: true, categories });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to retrieve categories' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const admin = checkAdminAuth(req);
    if (!admin) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    if (!body.name) {
      return NextResponse.json({ success: false, error: 'Category name is required' }, { status: 400 });
    }

    const slug = body.slug || body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    const id = body.id || `cat-${Date.now().toString().slice(-6)}`;

    const newCategory: Category = {
      id,
      name: body.name,
      slug,
      description: body.description || '',
      image: body.image || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80',
      order: Number(body.order) || 99,
    };

    const saved = saveCategory(newCategory);
    return NextResponse.json({ success: true, category: saved }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to create category' }, { status: 500 });
  }
}
