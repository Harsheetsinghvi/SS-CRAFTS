import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { NextRequest } from 'next/server';
import { getStoreSettings } from './db';

const JWT_SECRET = process.env.ADMIN_JWT_SECRET || 'ss_crafts_mdf_super_secret_jwt_key_2025_secure';
const TOKEN_COOKIE_NAME = 'mdf_admin_session';

export interface AdminPayload {
  email: string;
  role: 'admin';
  iat?: number;
  exp?: number;
}

/**
 * Verifies email and password against stored database hash
 */
export async function authenticateAdmin(email: string, plainPassword: string): Promise<boolean> {
  const settings = getStoreSettings();
  if (email.toLowerCase().trim() !== settings.adminEmail.toLowerCase().trim()) {
    return false;
  }
  return bcrypt.compare(plainPassword, settings.adminPasswordHash);
}

/**
 * Creates signed JWT for admin
 */
export function signAdminToken(email: string): string {
  const payload: AdminPayload = { email, role: 'admin' };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

/**
 * Verifies JWT token
 */
export function verifyAdminToken(token: string): AdminPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as AdminPayload;
  } catch (error) {
    return null;
  }
}

/**
 * Extracts and verifies admin auth token from NextRequest
 */
export function checkAdminAuth(req: NextRequest): AdminPayload | null {
  // Check cookie first
  const cookieToken = req.cookies.get(TOKEN_COOKIE_NAME)?.value;
  if (cookieToken) {
    const verified = verifyAdminToken(cookieToken);
    if (verified) return verified;
  }

  // Check Authorization Bearer header
  const authHeader = req.headers.get('authorization');
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const bearerToken = authHeader.substring(7);
    const verified = verifyAdminToken(bearerToken);
    if (verified) return verified;
  }

  return null;
}

export { TOKEN_COOKIE_NAME };
