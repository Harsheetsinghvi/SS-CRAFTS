import { Product } from './types';

export interface WhatsAppEnquiryOptions {
  product: Product;
  quantity?: number;
  finish?: string;
  customizationRequired?: string;
  customDimensions?: string;
  color?: string;
}

/**
 * Clean phone number to ensure digits only without '+' or dashes
 */
export function sanitizeWhatsAppNumber(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  // Default to 91 (India) prefix if 10 digits
  if (digits.length === 10) {
    return `91${digits}`;
  }
  return digits;
}

/**
 * Generates the standardized WhatsApp enquiry message as per Master Prompt specifications:
 *
 * “Hello, I am interested in the following MDF product.
 * Product Name: [Product Name]
 * Product ID: [Product ID]
 * Price: [Price]
 * Size: [Dimensions]
 * Material: [Material]
 * Finish: [Finish]
 * Quantity: [Selected Quantity]
 * Customization Required: [Customer Selection]
 * Please share availability, customization options, bulk pricing and delivery details.”
 */
export function buildProductEnquiryMessage(options: WhatsAppEnquiryOptions): string {
  const { product, quantity = product.moq || 1, finish, customizationRequired, customDimensions, color } = options;

  const sizeText = customDimensions
    ? `${customDimensions} (Custom Requested)`
    : `${product.dimensions.length} x ${product.dimensions.width} x ${product.dimensions.height} ${product.dimensions.unit} (Thickness: ${product.mdfThickness})`;

  const selectedFinish = finish || product.finishOptions[0] || 'Standard Raw Sanded';
  
  let customizationText = customizationRequired && customizationRequired.trim() !== ''
    ? customizationRequired.trim()
    : 'None (Standard catalogue design)';

  if (color) {
    customizationText += ` | Color/Stain: ${color}`;
  }

  const lines = [
    'Hello, I am interested in the following MDF product.',
    `Product Name: ${product.name}`,
    `Product ID: ${product.id}`,
    `Price: ₹${product.price} ${product.priceUnit || 'per piece'}`,
    `Size: ${sizeText}`,
    `Material: ${product.material}`,
    `Finish: ${selectedFinish}`,
    `Quantity: ${quantity}`,
    `Customization Required: ${customizationText}`,
    'Please share availability, customization options, bulk pricing and delivery details.',
  ];

  return lines.join('\n');
}

/**
 * Creates the complete https://wa.me/ URL with encoded message
 */
export function generateWhatsAppLink(phone: string, message: string): string {
  const cleanPhone = sanitizeWhatsAppNumber(phone);
  const encodedText = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encodedText}`;
}

/**
 * General enquiry message generator for custom orders or bulk requirements
 */
export function buildGeneralEnquiryMessage(details?: {
  topic?: string;
  name?: string;
  notes?: string;
}): string {
  const lines = [
    'Hello SS Crafts,',
    details?.name ? `My name is ${details.name}.` : '',
    details?.topic ? `Topic: ${details.topic}` : 'I am interested in exploring your MDF products & laser cutting services.',
    details?.notes ? `Requirement details: ${details.notes}` : '',
    'Please share your catalogue, MOQ details, and bulk pricing.',
  ].filter(Boolean);

  return lines.join('\n');
}
