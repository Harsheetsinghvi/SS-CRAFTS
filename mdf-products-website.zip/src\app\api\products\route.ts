import { NextRequest, NextResponse } from 'next/server';
import { getAllProducts, saveProduct } from '@/lib/db';
import { checkAdminAuth } from '@/lib/auth';
import { Product } from '@/lib/types';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search')?.toLowerCase();
    const minPrice = searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : null;
    const maxPrice = searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : null;
    const thickness = searchParams.get('thickness');
    const sort = searchParams.get('sort') || 'featured';
    const adminMode = searchParams.get('admin') === 'true';

    // If admin query param, verify auth
    const isAdmin = adminMode && checkAdminAuth(req) !== null;
    let products = getAllProducts(isAdmin);

    // Filter by Category
    if (category && category !== 'All') {
      products = products.filter(p => p.category.toLowerCase() === category.toLowerCase());
    }

    // Search query (name, description, material, id)
    if (search) {
      products = products.filter(
        p =>
          p.name.toLowerCase().includes(search) ||
          p.id.toLowerCase().includes(search) ||
          p.description.toLowerCase().includes(search) ||
          p.material.toLowerCase().includes(search) ||
          p.mdfThickness.toLowerCase().includes(search)
      );
    }

    // Price filters
    if (minPrice !== null && !isNaN(minPrice)) {
      products = products.filter(p => p.price >= minPrice);
    }
    if (maxPrice !== null && !isNaN(maxPrice)) {
      products = products.filter(p => p.price <= maxPrice);
    }

    // Thickness filter
    if (thickness) {
      products = products.filter(p => p.mdfThickness.toLowerCase().includes(thickness.toLowerCase()));
    }

    // Sorting
    if (sort === 'price_asc') {
      products.sort((a, b) => a.price - b.price);
    } else if (sort === 'price_desc') {
      products.sort((a, b) => b.price - a.price);
    } else if (sort === 'newest') {
      products.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } else if (sort === 'bestseller') {
      products.sort((a, b) => (b.bestseller ? 1 : 0) - (a.bestseller ? 1 : 0));
    } else {
      // 'featured'
      products.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }

    return NextResponse.json({
      success: true,
      count: products.length,
      products,
    });
  } catch (error) {
    console.error('Failed to get products:', error);
    return NextResponse.json({ success: false, error: 'Failed to retrieve products' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const admin = checkAdminAuth(req);
    if (!admin) {
      return NextResponse.json({ success: false, error: 'Unauthorized. Admin credentials required.' }, { status: 401 });
    }

    const body = await req.json();

    // Validation
    if (!body.name || !body.price || !body.category) {
      return NextResponse.json({ success: false, error: 'Name, price, and category are required' }, { status: 400 });
    }

    const id = body.id || `MDF-${Date.now().toString().slice(-6)}`;
    const slug = body.slug || body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    const newProduct: Product = {
      id,
      name: body.name,
      slug,
      category: body.category,
      price: Number(body.price),
      priceUnit: body.priceUnit || 'per piece',
      moq: Number(body.moq) || 10,
      dimensions: {
        length: Number(body.dimensions?.length) || 100,
        width: Number(body.dimensions?.width) || 100,
        height: Number(body.dimensions?.height) || 50,
        unit: body.dimensions?.unit || 'mm',
      },
      mdfThickness: body.mdfThickness || '5.5mm High-Density MDF',
      material: body.material || 'Export Grade Pine MDF',
      finishOptions: Array.isArray(body.finishOptions) && body.finishOptions.length > 0 ? body.finishOptions : ['Raw Sanded'],
      colorOptions: Array.isArray(body.colorOptions) && body.colorOptions.length > 0 ? body.colorOptions : ['Natural Wood'],
      customizationAvailable: body.customizationAvailable ?? true,
      featured: body.featured ?? false,
      bestseller: body.bestseller ?? false,
      isNew: body.isNew ?? true,
      published: body.published ?? true,
      images: Array.isArray(body.images) && body.images.length > 0 ? body.images : ['https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80'],
      description: body.description || 'Premium handcrafted MDF product suitable for gifts, custom branding, and craft work.',
      stockStatus: body.stockStatus || 'In Stock',
      laserDetailLevel: body.laserDetailLevel || 'Plain',
      rating: 5.0,
      reviewsCount: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const saved = saveProduct(newProduct);
    return NextResponse.json({ success: true, product: saved }, { status: 201 });
  } catch (error) {
    console.error('Failed to create product:', error);
    return NextResponse.json({ success: false, error: 'Failed to create product' }, { status: 500 });
  }
}
