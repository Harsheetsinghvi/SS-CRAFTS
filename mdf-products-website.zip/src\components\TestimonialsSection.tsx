import React from 'react';
import { Star, Quote, Building2, Palette, Sparkles } from 'lucide-react';

export default function TestimonialsSection() {
  const reviews = [
    {
      name: 'Aditi Sharma',
      role: 'Founder, The Resin Palette Studio',
      city: 'Pune, Maharashtra',
      rating: 5,
      review: 'Their pre-marked MDF peacock rangoli and clock bases have completely upgraded our art workshops. The laser etching is crisp, and the wood doesn’t swell even with heavy resin pours.',
      category: 'Art & Craft Studio',
    },
    {
      name: 'Vikram Mehta',
      role: 'Director, Vivah Weddings & Celebrations',
      city: 'Udaipur, Rajasthan',
      rating: 5,
      review: 'We ordered 350 customized Mughal jali trousseau boxes with magnetic lids for a royal destination wedding. The samples arrived in 3 days, and the batch quality was impeccable.',
      category: 'Wedding Planner',
    },
    {
      name: 'Ritu Sen',
      role: 'Senior Procurement Lead, TechKraft Media',
      city: 'Gurugram, Haryana',
      rating: 5,
      review: 'Finding a manufacturer who delivers bulk laser-engraved executive desk boxes on time during Diwali is rare. Direct WhatsApp coordination made revisions effortless.',
      category: 'Corporate Client',
    },
  ];

  return (
    <section style={{ padding: '5.5rem 0', backgroundColor: 'var(--color-cream-white)' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span
            style={{
              fontSize: '0.8rem',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: 'var(--color-walnut-brown)',
              fontWeight: 700,
              display: 'block',
              marginBottom: '0.5rem',
            }}
          >
            Client Experiences
          </span>
          <h2 className="section-title">Trusted by Crafters & Event Curators</h2>
          <p className="section-subtitle">
            See how artists, wedding planners, and corporate clients across India rely on our MDF fabrication.
          </p>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '2rem',
          }}
        >
          {reviews.map((rev, idx) => (
            <div
              key={idx}
              style={{
                backgroundColor: 'var(--color-warm-ivory)',
                padding: '2.25rem',
                borderRadius: 'var(--radius-lg)',
                border: '1px solid var(--color-border-subtle)',
                boxShadow: 'var(--shadow-card)',
                display: 'flex',
                flexDirection: 'column',
                position: 'relative',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.25rem' }}>
                <div style={{ display: 'flex', gap: '2px', color: '#E09F3E' }}>
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} size={16} fill="#E09F3E" />
                  ))}
                </div>
                <span
                  style={{
                    fontSize: '0.72rem',
                    backgroundColor: 'rgba(138, 96, 69, 0.1)',
                    color: 'var(--color-walnut-brown)',
                    padding: '0.2rem 0.6rem',
                    borderRadius: 'var(--radius-pill)',
                    fontWeight: 600,
                  }}
                >
                  {rev.category}
                </span>
              </div>

              <p
                style={{
                  fontSize: '0.92rem',
                  color: 'var(--color-espresso)',
                  lineHeight: 1.65,
                  fontStyle: 'italic',
                  marginBottom: '1.5rem',
                  flex: 1,
                }}
              >
                &ldquo;{rev.review}&rdquo;
              </p>

              <div style={{ borderTop: '1px solid var(--color-border)', paddingTop: '1rem' }}>
                <strong style={{ fontSize: '0.98rem', display: 'block', color: 'var(--color-espresso)' }}>
                  {rev.name}
                </strong>
                <span style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)', display: 'block' }}>
                  {rev.role}
                </span>
                <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>
                  {rev.city}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
