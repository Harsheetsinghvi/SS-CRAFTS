'use client';

import React from 'react';
import Image from 'next/image';
import { MessageCircle, Eye, Ruler, Layers, Sparkles, Check } from 'lucide-react';
import { Product } from '@/lib/types';
import { buildProductEnquiryMessage, generateWhatsAppLink } from '@/lib/whatsapp';

interface ProductCardProps {
  product: Product;
  whatsappNumber: string;
  onViewDetails: (product: Product) => void;
}

export default function ProductCard({ product, whatsappNumber, onViewDetails }: ProductCardProps) {
  const primaryImage = product.images?.[0] || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80';
  
  const formattedDimensions = `${product.dimensions.length}×${product.dimensions.width}×${product.dimensions.height} ${product.dimensions.unit}`;

  // Build the standardized WhatsApp message
  const whatsappMessage = buildProductEnquiryMessage({
    product,
    quantity: product.moq || 10,
    finish: product.finishOptions[0] || 'Raw Sanded',
    customizationRequired: 'Standard catalogue specifications',
  });

  const whatsappUrl = generateWhatsAppLink(whatsappNumber, whatsappMessage);

  const handleWhatsAppClick = async (e: React.MouseEvent) => {
    // Optionally log enquiry in background
    try {
      fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: product.id,
          productName: product.name,
          productPrice: product.price,
          quantity: product.moq || 10,
          dimensions: formattedDimensions,
          material: product.material,
          finish: product.finishOptions[0] || 'Raw Sanded',
          source: 'whatsapp_click',
        }),
      }).catch(() => {});
    } catch (err) {}
  };

  return (
    <article className="product-card" id={`product-${product.id}`}>
      {/* Product Image Wrapper */}
      <div className="product-image-wrapper">
        <Image
          src={primaryImage}
          alt={product.name}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          priority={false}
          style={{ objectFit: 'cover' }}
        />

        {/* Badges Overlay */}
        <div style={{ position: 'absolute', top: '10px', left: '10px', display: 'flex', flexDirection: 'column', gap: '5px', zIndex: 2 }}>
          {product.bestseller && (
            <span className="badge badge-bestseller">
              ★ Bestseller
            </span>
          )}
          {product.isNew && (
            <span className="badge badge-new">
              ✨ New
            </span>
          )}
          {product.customizationAvailable && (
            <span className="badge badge-custom">
              Customizable
            </span>
          )}
        </div>

        {/* Stock / MOQ pill */}
        <div style={{ position: 'absolute', bottom: '10px', right: '10px', zIndex: 2 }}>
          <span
            style={{
              fontSize: '0.7rem',
              fontWeight: 600,
              backgroundColor: 'rgba(41, 35, 31, 0.75)',
              color: '#FFFFFF',
              padding: '0.2rem 0.6rem',
              borderRadius: 'var(--radius-pill)',
              backdropFilter: 'blur(4px)',
            }}
          >
            MOQ: {product.moq} pcs
          </span>
        </div>
      </div>

      {/* Product Card Content */}
      <div className="product-card-body">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className="product-category-label">{product.category}</span>
          <span style={{ fontSize: '0.72rem', color: 'var(--color-text-light)', fontFamily: 'monospace' }}>
            ID: {product.id}
          </span>
        </div>

        <h3 className="product-title" title={product.name}>
          {product.name}
        </h3>

        {/* Specification chips */}
        <div className="product-specs-summary">
          <span className="product-spec-pill" title="Dimensions">
            <Ruler size={13} style={{ color: 'var(--color-walnut-brown)' }} />
            {formattedDimensions}
          </span>
          <span className="product-spec-pill" title="Thickness">
            <Layers size={13} style={{ color: 'var(--color-walnut-brown)' }} />
            {product.mdfThickness.split(' ')[0]}
          </span>
        </div>

        <p style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', marginBottom: '0.75rem', lineHeight: 1.4 }}>
          {product.material} &bull; {product.finishOptions[0]}
        </p>

        {/* Footer with Price and Actions */}
        <div className="product-card-footer">
          <div className="product-price-block">
            <span className="product-price">₹{product.price}</span>
            <span className="product-unit">{product.priceUnit || 'per piece'}</span>
          </div>

          <div style={{ display: 'flex', gap: '0.45rem', alignItems: 'center' }}>
            {/* View Details Button */}
            <button
              onClick={() => onViewDetails(product)}
              className="btn btn-secondary btn-sm"
              title="View full specs and configure customization"
              style={{ padding: '0.45rem 0.75rem' }}
            >
              <Eye size={15} />
              <span>Details</span>
            </button>

            {/* Enquire on WhatsApp Button */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleWhatsAppClick}
              className="btn btn-whatsapp btn-sm"
              title="Enquire directly on WhatsApp"
              style={{ padding: '0.45rem 0.85rem' }}
            >
              <MessageCircle size={15} />
              <span>Enquire</span>
            </a>
          </div>
        </div>
      </div>
    </article>
  );
}
