'use client';

import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

interface FaqProps {
  whatsappNumber: string;
}

export default function FaqSection({ whatsappNumber }: FaqProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const cleanPhone = sanitizeWhatsAppNumber(whatsappNumber);

  const faqs = [
    {
      q: 'What is the Minimum Order Quantity (MOQ) for catalogue products?',
      a: 'Standard catalogue products typically have an MOQ of 5 to 15 pieces, depending on the complexity of the box or tray. For customized sizing or logo engraving, our MOQ is generally 20 to 50 pieces. We also provide sample single pieces for approval before confirming bulk runs.',
    },
    {
      q: 'Can I order boxes or bases in custom dimensions not shown in the catalogue?',
      a: 'Yes! Custom fabrication is our speciality. You can request any length, width, and depth in millimetres, and select MDF thicknesses ranging from 2.5mm, 3.2mm, 5.5mm, 8mm to 12mm. Just use our custom enquiry calculator or ping us on WhatsApp.',
    },
    {
      q: 'How does the WhatsApp ordering process work?',
      a: 'We keep ordering simple and flexible! When you click "Enquire on WhatsApp" on any product, a prefilled message with the exact product title, SKU, dimensions, finish, and selected quantity opens in your WhatsApp chat. Our team reviews stock, calculates shipping, answers customization requests, and confirms payment details directly.',
    },
    {
      q: 'What finishes are available on your MDF products?',
      a: 'We supply: (1) Raw Sanded MDF (320-grit smooth, ready for resin art, acrylic paints, or decoupage), (2) White Primed MDF (ideal for vibrant paint applications), (3) Warm Walnut & Teak Wood Stained with clear matte lacquer, and (4) Melamine Laminated boards with clean routed edges.',
    },
    {
      q: 'Are your MDF bases suitable for Resin Art, Lippan Art, and Fluid Pouring?',
      a: 'Absolutely. We exclusively use high-density, export-grade moisture resistant Pine MDF boards. The fine particle density prevents board swelling, bubbling, or warping when exposed to resin epoxies, heavy texture pastes, or clay work.',
    },
    {
      q: 'What are your delivery timelines and packing standards for bulk cartons?',
      a: 'Catalog ready items are dispatched within 24 to 48 hours. Custom laser orders typically take 3 to 6 working days. All shipments are cushioned in bubble wraps, corner protectors, and packed into heavy-duty 5-ply cartons or wooden crates for safe transit across India.',
    },
  ];

  return (
    <section style={{ padding: '5.5rem 0', backgroundColor: 'var(--color-warm-ivory)' }}>
      <div className="container" style={{ maxWidth: '860px' }}>
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span
            style={{
              fontSize: '0.8rem',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: 'var(--color-walnut-brown)',
              fontWeight: 700,
              display: 'block',
              marginBottom: '0.5rem',
            }}
          >
            Clear Answers
          </span>
          <h2 className="section-title">Frequently Asked Questions</h2>
          <p className="section-subtitle">
            Everything you need to know about our MDF products, customization, MOQ, and ordering.
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                style={{
                  backgroundColor: 'var(--color-cream-white)',
                  borderRadius: 'var(--radius-md)',
                  border: '1px solid var(--color-border)',
                  overflow: 'hidden',
                  transition: 'var(--transition)',
                }}
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  style={{
                    width: '100%',
                    padding: '1.25rem 1.5rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    textAlign: 'left',
                    gap: '1rem',
                  }}
                  aria-expanded={isOpen}
                >
                  <span
                    style={{
                      fontFamily: 'var(--font-heading)',
                      fontSize: '1.08rem',
                      fontWeight: 600,
                      color: isOpen ? 'var(--color-walnut-brown)' : 'var(--color-espresso)',
                    }}
                  >
                    {faq.q}
                  </span>
                  <div
                    style={{
                      transform: isOpen ? 'rotate(180deg)' : 'rotate(0)',
                      transition: 'transform 0.25s ease',
                      color: 'var(--color-walnut-brown)',
                      flexShrink: 0,
                    }}
                  >
                    <ChevronDown size={20} />
                  </div>
                </button>

                {isOpen && (
                  <div
                    style={{
                      padding: '0 1.5rem 1.25rem',
                      fontSize: '0.92rem',
                      color: 'var(--color-text-muted)',
                      lineHeight: 1.65,
                      borderTop: '1px solid var(--color-border-subtle)',
                      paddingTop: '0.9rem',
                    }}
                  >
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div
          style={{
            marginTop: '3rem',
            textAlign: 'center',
            backgroundColor: '#FFFFFF',
            borderRadius: 'var(--radius-md)',
            padding: '1.5rem',
            border: '1px solid var(--color-border-subtle)',
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
          }}
        >
          <div style={{ textAlign: 'left' }}>
            <strong style={{ fontSize: '1rem', color: 'var(--color-espresso)', display: 'block' }}>
              Have a question not listed here?
            </strong>
            <span style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)' }}>
              Chat directly with our fabrication specialists on WhatsApp.
            </span>
          </div>

          <a
            href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent('Hello SS Crafts, I have a question regarding MDF specifications and ordering.')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="btn btn-whatsapp btn-sm"
          >
            <MessageCircle size={16} />
            <span>Ask on WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
}
