'use client';

import React from 'react';
import { MessageCircle } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

interface FloatingWhatsAppProps {
  whatsappNumber?: string;
  storeName?: string;
}

export default function FloatingWhatsApp({
  whatsappNumber = '919313229609',
  storeName = 'SS Crafts',
}: FloatingWhatsAppProps) {
  const cleanPhone = sanitizeWhatsAppNumber(whatsappNumber);
  const defaultText = `Hello ${storeName}, I am browsing your MDF catalogue and would like to enquire about products, custom laser cutting, and bulk pricing.`;
  const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(defaultText)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="floating-whatsapp"
      title="Chat directly on WhatsApp"
      aria-label="Direct WhatsApp Enquiry"
    >
      <MessageCircle size={24} />
      <span>Quick WhatsApp Chat</span>
    </a>
  );
}
