'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  Search,
  SlidersHorizontal,
  X,
  RotateCcw,
  Ruler,
  Layers,
  ArrowUpDown,
  Filter,
  Grid,
  List
} from 'lucide-react';
import { Product, Category } from '@/lib/types';
import ProductCard from '@/components/ProductCard';
import ProductModal from '@/components/ProductModal';

interface CatalogueViewProps {
  initialProducts: Product[];
  categories: Category[];
  whatsappNumber: string;
}

export default function CatalogueView({
  initialProducts,
  categories,
  whatsappNumber,
}: CatalogueViewProps) {
  const searchParams = useSearchParams();
  const router = useRouter();

  // Query parameter defaults
  const paramCategory = searchParams.get('category') || 'All';
  const paramSearch = searchParams.get('search') || '';

  // Filter states
  const [searchQuery, setSearchQuery] = useState(paramSearch);
  const [selectedCategory, setSelectedCategory] = useState(paramCategory);
  const [selectedThickness, setSelectedThickness] = useState('All');
  const [minPrice, setMinPrice] = useState<number | ''>('');
  const [maxPrice, setMaxPrice] = useState<number | ''>('');
  const [sortBy, setSortBy] = useState('featured');
  const [onlyCustomizable, setOnlyCustomizable] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Pagination / Load More state
  const [displayCount, setDisplayCount] = useState(12);

  // Modal state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Mobile drawer state
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Sync category from URL when it changes
  useEffect(() => {
    if (paramCategory) {
      setSelectedCategory(paramCategory);
    }
  }, [paramCategory]);

  // Available thickness options extracted from products
  const thicknessOptions = useMemo(() => {
    const set = new Set<string>();
    initialProducts.forEach((p) => {
      const match = p.mdfThickness.match(/^[\d\.]+mm/i);
      if (match) set.add(match[0]);
    });
    return Array.from(set).sort();
  }, [initialProducts]);

  // Filter & Sort Logic
  const filteredProducts = useMemo(() => {
    return initialProducts
      .filter((p) => {
        // Category Filter
        if (selectedCategory !== 'All' && p.category.toLowerCase() !== selectedCategory.toLowerCase()) {
          return false;
        }

        // Search Filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matches =
            p.name.toLowerCase().includes(q) ||
            p.id.toLowerCase().includes(q) ||
            p.description.toLowerCase().includes(q) ||
            p.material.toLowerCase().includes(q) ||
            p.category.toLowerCase().includes(q);
          if (!matches) return false;
        }

        // Thickness Filter
        if (selectedThickness !== 'All') {
          if (!p.mdfThickness.toLowerCase().includes(selectedThickness.toLowerCase())) {
            return false;
          }
        }

        // Price Filters
        if (minPrice !== '' && p.price < Number(minPrice)) return false;
        if (maxPrice !== '' && p.price > Number(maxPrice)) return false;

        // Customization Filter
        if (onlyCustomizable && !p.customizationAvailable) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price_asc') return a.price - b.price;
        if (sortBy === 'price_desc') return b.price - a.price;
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        if (sortBy === 'bestseller') return (b.bestseller ? 1 : 0) - (a.bestseller ? 1 : 0);
        // Featured
        return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      });
  }, [
    initialProducts,
    selectedCategory,
    searchQuery,
    selectedThickness,
    minPrice,
    maxPrice,
    onlyCustomizable,
    sortBy,
  ]);

  const displayedProducts = filteredProducts.slice(0, displayCount);

  // Reset all filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedThickness('All');
    setMinPrice('');
    setMaxPrice('');
    setOnlyCustomizable(false);
    setSortBy('featured');
    setDisplayCount(12);
  };

  const isFiltered =
    selectedCategory !== 'All' ||
    searchQuery !== '' ||
    selectedThickness !== 'All' ||
    minPrice !== '' ||
    maxPrice !== '' ||
    onlyCustomizable;

  return (
    <div style={{ padding: '3rem 0 6rem', backgroundColor: 'var(--color-warm-ivory)' }}>
      <div className="container">
        {/* Header Breadcrumb & Title */}
        <div style={{ marginBottom: '2.5rem' }}>
          <span
            style={{
              fontSize: '0.8rem',
              letterSpacing: '0.1em',
              textTransform: 'uppercase',
              color: 'var(--color-walnut-brown)',
              fontWeight: 700,
              display: 'block',
              marginBottom: '0.3rem',
            }}
          >
            Direct Factory Catalogue
          </span>
          <h1 className="display-title" style={{ fontSize: 'clamp(2rem, 4vw, 2.8rem)', margin: 0 }}>
            MDF Products & Laser Cut Catalogue
          </h1>
          <p style={{ fontSize: '1rem', color: 'var(--color-text-muted)', marginTop: '0.5rem' }}>
            Browse boxes, trays, wedding hampers, pre-marked DIY art bases, and customized laser designs. Select quantities and enquire directly on WhatsApp.
          </p>
        </div>

        {/* Top Control Bar: Search & Sort & Mobile Filter Toggle */}
        <div
          style={{
            backgroundColor: 'var(--color-cream-white)',
            borderRadius: 'var(--radius-lg)',
            padding: '1.25rem',
            boxShadow: 'var(--shadow-card)',
            border: '1px solid var(--color-border)',
            marginBottom: '2.5rem',
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: '1rem',
          }}
        >
          {/* Search Bar */}
          <div
            style={{
              position: 'relative',
              flex: '1 1 300px',
              maxWidth: '480px',
            }}
          >
            <Search
              size={18}
              style={{
                position: 'absolute',
                top: '50%',
                left: '1rem',
                transform: 'translateY(-50%)',
                color: 'var(--color-text-light)',
              }}
            />
            <input
              type="text"
              placeholder="Search by product name, SKU (e.g. MDF-BX-101), material..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="form-input"
              style={{
                paddingLeft: '2.6rem',
                paddingRight: searchQuery ? '2.5rem' : '1rem',
                borderRadius: 'var(--radius-pill)',
                backgroundColor: 'var(--color-warm-ivory)',
              }}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                style={{
                  position: 'absolute',
                  top: '50%',
                  right: '0.8rem',
                  transform: 'translateY(-50%)',
                  color: 'var(--color-text-light)',
                }}
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Right Controls: Sort Dropdown & Mobile Filter Button */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
            {/* Mobile Filter Toggle */}
            <button
              onClick={() => setMobileFilterOpen(true)}
              className="btn btn-secondary btn-sm mobile-filter-btn"
              style={{ display: 'none' }}
            >
              <SlidersHorizontal size={15} />
              <span>Filters {isFiltered && '(Active)'}</span>
            </button>

            {/* Sort Dropdown */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--color-text-muted)', whiteSpace: 'nowrap' }}>
                Sort by:
              </span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="form-select"
                style={{
                  padding: '0.55rem 1rem',
                  fontSize: '0.88rem',
                  borderRadius: 'var(--radius-pill)',
                  width: 'auto',
                }}
              >
                <option value="featured">Featured First</option>
                <option value="bestseller">Bestsellers</option>
                <option value="newest">Newest Arrivals</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Main Content Layout: Sidebar Filters + Products Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '280px 1fr', gap: '2.5rem' }} className="catalogue-layout">
          {/* Desktop Filter Sidebar */}
          <aside className="catalogue-sidebar" style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
            {/* Category Filter Card */}
            <div
              style={{
                backgroundColor: 'var(--color-cream-white)',
                borderRadius: 'var(--radius-lg)',
                padding: '1.5rem',
                border: '1px solid var(--color-border)',
                boxShadow: 'var(--shadow-sm)',
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.15rem', margin: 0 }}>
                  Categories
                </h3>
                {selectedCategory !== 'All' && (
                  <button
                    onClick={() => setSelectedCategory('All')}
                    style={{ fontSize: '0.75rem', color: 'var(--color-walnut-brown)', fontWeight: 600 }}
                  >
                    Clear
                  </button>
                )}
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                <button
                  onClick={() => setSelectedCategory('All')}
                  style={{
                    textAlign: 'left',
                    padding: '0.5rem 0.75rem',
                    borderRadius: 'var(--radius-sm)',
                    fontSize: '0.88rem',
                    fontWeight: selectedCategory === 'All' ? 700 : 500,
                    backgroundColor: selectedCategory === 'All' ? 'var(--color-warm-ivory)' : 'transparent',
                    color: selectedCategory === 'All' ? 'var(--color-walnut-brown)' : 'var(--color-espresso)',
                    display: 'flex',
                    justifyContent: 'space-between',
                  }}
                >
                  <span>All Categories</span>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>
                    {initialProducts.length}
                  </span>
                </button>

                {categories.map((cat) => {
                  const isSelected = selectedCategory.toLowerCase() === cat.name.toLowerCase();
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.name)}
                      style={{
                        textAlign: 'left',
                        padding: '0.5rem 0.75rem',
                        borderRadius: 'var(--radius-sm)',
                        fontSize: '0.88rem',
                        fontWeight: isSelected ? 700 : 500,
                        backgroundColor: isSelected ? 'var(--color-warm-ivory)' : 'transparent',
                        color: isSelected ? 'var(--color-walnut-brown)' : 'var(--color-espresso)',
                        display: 'flex',
                        justifyContent: 'space-between',
                      }}
                    >
                      <span>{cat.name}</span>
                      {cat.productCount !== undefined && (
                        <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>
                          {cat.productCount}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Thickness Filter Card */}
            <div
              style={{
                backgroundColor: 'var(--color-cream-white)',
                borderRadius: 'var(--radius-lg)',
                padding: '1.5rem',
                border: '1px solid var(--color-border)',
                boxShadow: 'var(--shadow-sm)',
              }}
            >
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.15rem', marginBottom: '1rem' }}>
                MDF Thickness
              </h3>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
                <button
                  onClick={() => setSelectedThickness('All')}
                  style={{
                    padding: '0.35rem 0.75rem',
                    borderRadius: 'var(--radius-pill)',
                    fontSize: '0.8rem',
                    fontWeight: 600,
                    backgroundColor: selectedThickness === 'All' ? 'var(--color-espresso)' : 'var(--color-warm-ivory)',
                    color: selectedThickness === 'All' ? '#FFFFFF' : 'var(--color-espresso)',
                    border: '1px solid var(--color-border-subtle)',
                  }}
                >
                  All
                </button>
                {thicknessOptions.map((th) => (
                  <button
                    key={th}
                    onClick={() => setSelectedThickness(th)}
                    style={{
                      padding: '0.35rem 0.75rem',
                      borderRadius: 'var(--radius-pill)',
                      fontSize: '0.8rem',
                      fontWeight: 600,
                      backgroundColor: selectedThickness === th ? 'var(--color-espresso)' : 'var(--color-warm-ivory)',
                      color: selectedThickness === th ? '#FFFFFF' : 'var(--color-espresso)',
                      border: '1px solid var(--color-border-subtle)',
                    }}
                  >
                    {th}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range Filter Card */}
            <div
              style={{
                backgroundColor: 'var(--color-cream-white)',
                borderRadius: 'var(--radius-lg)',
                padding: '1.5rem',
                border: '1px solid var(--color-border)',
                boxShadow: 'var(--shadow-sm)',
              }}
            >
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.15rem', marginBottom: '1rem' }}>
                Price Range (₹)
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.6rem', marginBottom: '1rem' }}>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', display: 'block', marginBottom: '0.2rem' }}>Min Price</label>
                  <input
                    type="number"
                    placeholder="₹ Min"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value ? Number(e.target.value) : '')}
                    className="form-input"
                    style={{ padding: '0.45rem', fontSize: '0.85rem' }}
                  />
                </div>
                <div>
                  <label style={{ fontSize: '0.75rem', color: 'var(--color-text-light)', display: 'block', marginBottom: '0.2rem' }}>Max Price</label>
                  <input
                    type="number"
                    placeholder="₹ Max"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : '')}
                    className="form-input"
                    style={{ padding: '0.45rem', fontSize: '0.85rem' }}
                  />
                </div>
              </div>

              {/* Customization checkbox */}
              <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.85rem', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  checked={onlyCustomizable}
                  onChange={(e) => setOnlyCustomizable(e.target.checked)}
                />
                <span>Customization Available Only</span>
              </label>

              {/* Reset All Filters button */}
              {isFiltered && (
                <button
                  onClick={handleResetFilters}
                  className="btn btn-secondary btn-sm"
                  style={{ width: '100%', marginTop: '1.25rem', justifyContent: 'center' }}
                >
                  <RotateCcw size={14} />
                  <span>Reset All Filters</span>
                </button>
              )}
            </div>
          </aside>

          {/* Product Grid / Results Area */}
          <div>
            {/* Status bar: count & active tags */}
            <div
              style={{
                display: 'flex',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '1rem',
                marginBottom: '1.5rem',
              }}
            >
              <div style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)' }}>
                Showing <strong>{displayedProducts.length}</strong> of <strong>{filteredProducts.length}</strong> products
                {selectedCategory !== 'All' && <span> in <strong>{selectedCategory}</strong></span>}
                {searchQuery && <span> matching &ldquo;<strong>{searchQuery}</strong>&rdquo;</span>}
              </div>

              {isFiltered && (
                <button
                  onClick={handleResetFilters}
                  style={{
                    fontSize: '0.82rem',
                    color: 'var(--color-walnut-brown)',
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.3rem',
                  }}
                >
                  <RotateCcw size={13} /> Reset Filters
                </button>
              )}
            </div>

            {/* Products Grid */}
            {displayedProducts.length > 0 ? (
              <>
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
                    gap: '2rem',
                  }}
                >
                  {displayedProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      whatsappNumber={whatsappNumber}
                      onViewDetails={(p) => setSelectedProduct(p)}
                    />
                  ))}
                </div>

                {/* Load More Button if more products exist */}
                {filteredProducts.length > displayCount && (
                  <div style={{ textAlign: 'center', marginTop: '3.5rem' }}>
                    <button
                      onClick={() => setDisplayCount((prev) => prev + 12)}
                      className="btn btn-secondary btn-lg"
                    >
                      Load More Products ({filteredProducts.length - displayCount} remaining)
                    </button>
                  </div>
                )}
              </>
            ) : (
              /* Clear Empty State */
              <div
                style={{
                  backgroundColor: 'var(--color-cream-white)',
                  borderRadius: 'var(--radius-lg)',
                  padding: '4rem 2rem',
                  textAlign: 'center',
                  border: '1px solid var(--color-border)',
                }}
              >
                <div
                  style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '50%',
                    backgroundColor: 'var(--color-warm-ivory)',
                    color: 'var(--color-walnut-brown)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 1.5rem',
                  }}
                >
                  <Search size={28} />
                </div>
                <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', marginBottom: '0.5rem' }}>
                  No Products Found
                </h3>
                <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', maxWidth: '440px', margin: '0 auto 1.5rem' }}>
                  We couldn’t find any MDF products matching your search criteria. Try clearing some filters or inquire for custom manufacturing.
                </p>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap' }}>
                  <button onClick={handleResetFilters} className="btn btn-primary">
                    <RotateCcw size={16} />
                    <span>Reset All Filters</span>
                  </button>
                  <a
                    href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent('Hello, I was looking for a specific MDF product not found in the catalogue. Can you manufacture it?')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-whatsapp"
                  >
                    Ask Custom Design on WhatsApp
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileFilterOpen && (
        <div className="modal-overlay" onClick={() => setMobileFilterOpen(false)}>
          <div
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
            style={{ maxWidth: '400px', maxHeight: '80vh', padding: '1.5rem' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.3rem', margin: 0 }}>Filter Catalogue</h3>
              <button onClick={() => setMobileFilterOpen(false)}><X size={20} /></button>
            </div>

            {/* Category selection */}
            <div style={{ marginBottom: '1.5rem' }}>
              <label className="form-label" style={{ fontSize: '0.85rem' }}>Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="form-select"
              >
                <option value="All">All Categories ({initialProducts.length})</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>

            {/* Thickness */}
            <div style={{ marginBottom: '1.5rem' }}>
              <label className="form-label" style={{ fontSize: '0.85rem' }}>MDF Thickness</label>
              <select
                value={selectedThickness}
                onChange={(e) => setSelectedThickness(e.target.value)}
                className="form-select"
              >
                <option value="All">All Thicknesses</option>
                {thicknessOptions.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <button
              onClick={() => setMobileFilterOpen(false)}
              className="btn btn-primary"
              style={{ width: '100%', justifyContent: 'center' }}
            >
              Apply Filters
            </button>
          </div>
        </div>
      )}

      {/* Product Detail Modal */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          whatsappNumber={whatsappNumber}
          onClose={() => setSelectedProduct(null)}
        />
      )}

      <style jsx>{`
        @media (max-width: 880px) {
          .catalogue-layout {
            grid-template-columns: 1fr !important;
          }
          .catalogue-sidebar {
            display: none !important;
          }
          .mobile-filter-btn {
            display: inline-flex !important;
          }
        }
      `}</style>
    </div>
  );
}
