'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { Category } from '@/lib/types';

interface CategoryGridProps {
  categories: Category[];
}

export default function CategoryGrid({ categories }: CategoryGridProps) {
  return (
    <section style={{ padding: '5rem 0', backgroundColor: 'var(--color-cream-white)' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span
            style={{
              fontSize: '0.8rem',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: 'var(--color-walnut-brown)',
              fontWeight: 700,
              display: 'block',
              marginBottom: '0.5rem',
            }}
          >
            Curated Collections
          </span>
          <h2 className="section-title">Explore MDF Categories</h2>
          <p className="section-subtitle">
            From precision laser-etched DIY bases to luxury wedding hamper cases and corporate gifting suites, explore our comprehensive range.
          </p>
        </div>

        {/* Category Cards Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
            gap: '1.75rem',
          }}
        >
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/catalogue?category=${encodeURIComponent(cat.name)}`}
              style={{
                backgroundColor: 'var(--color-warm-ivory)',
                borderRadius: 'var(--radius-lg)',
                overflow: 'hidden',
                border: '1px solid var(--color-border-subtle)',
                boxShadow: 'var(--shadow-card)',
                transition: 'var(--transition)',
                display: 'flex',
                flexDirection: 'column',
              }}
              className="category-card"
            >
              <div
                style={{
                  position: 'relative',
                  width: '100%',
                  paddingTop: '65%',
                  overflow: 'hidden',
                  backgroundColor: 'var(--color-sand-beige)',
                }}
              >
                <Image
                  src={cat.image || 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80'}
                  alt={cat.name}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                  style={{ objectFit: 'cover', transition: 'transform 0.4s ease' }}
                  className="category-image"
                />
                {cat.productCount !== undefined && cat.productCount > 0 && (
                  <span
                    style={{
                      position: 'absolute',
                      top: '10px',
                      right: '10px',
                      backgroundColor: 'rgba(41, 35, 31, 0.75)',
                      color: '#FFFFFF',
                      fontSize: '0.72rem',
                      fontWeight: 600,
                      padding: '0.2rem 0.55rem',
                      borderRadius: 'var(--radius-pill)',
                      backdropFilter: 'blur(4px)',
                    }}
                  >
                    {cat.productCount} Items
                  </span>
                )}
              </div>

              <div style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', flex: 1 }}>
                <h3
                  style={{
                    fontFamily: 'var(--font-heading)',
                    fontSize: '1.15rem',
                    color: 'var(--color-espresso)',
                    marginBottom: '0.4rem',
                  }}
                >
                  {cat.name}
                </h3>
                <p
                  style={{
                    fontSize: '0.82rem',
                    color: 'var(--color-text-muted)',
                    lineHeight: 1.45,
                    marginBottom: '1rem',
                    flex: 1,
                  }}
                >
                  {cat.description}
                </p>

                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.35rem',
                    color: 'var(--color-walnut-brown)',
                    fontSize: '0.85rem',
                    fontWeight: 600,
                    marginTop: 'auto',
                  }}
                >
                  <span>Browse Products</span>
                  <ArrowRight size={14} />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <style jsx>{`
        .category-card:hover {
          transform: translateY(-5px);
          box-shadow: var(--shadow-hover);
          border-color: var(--color-walnut-brown);
        }
        .category-card:hover :global(.category-image) {
          transform: scale(1.06);
        }
      `}</style>
    </section>
  );
}
