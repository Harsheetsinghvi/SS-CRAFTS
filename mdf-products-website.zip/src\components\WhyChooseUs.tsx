'use client';

import React from 'react';
import { Box, ShieldCheck, Zap, Factory, Truck, Sparkles } from 'lucide-react';

export default function WhyChooseUs() {
  const points = [
    {
      icon: <Factory size={28} />,
      title: 'Direct Factory Manufacturing',
      desc: 'Produced directly in our Gujarat manufacturing facility. Enjoy transparent pricing with zero middleman or distributor markups.',
    },
    {
      icon: <Zap size={28} />,
      title: '0.1mm Laser Precision',
      desc: 'Equipped with high-precision optical laser cutters for flawless jali fretwork, micro-engraving, and accurate joint interlocking.',
    },
    {
      icon: <ShieldCheck size={28} />,
      title: 'High-Density Pine MDF',
      desc: 'We utilize calibrated, moisture-resistant pine core boards that resist warping and provide an ultra-smooth surface for painting and resin.',
    },
    {
      icon: <Sparkles size={28} />,
      title: 'Custom Branding & Sizing',
      desc: 'Easily customize dimensions, slide lids, partition trays, or engrave company logos and wedding monograms on any product.',
    },
    {
      icon: <Box size={28} />,
      title: 'Zero Splinter Finishing',
      desc: 'Each unit undergoes multi-stage orbital sanding with 320-grit abrasives to ensure baby-smooth edges and safe handling.',
    },
    {
      icon: <Truck size={28} />,
      title: 'Pan-India Secure Dispatch',
      desc: 'Reinforced 5-ply corrugated carton and wooden crate packing ensure break-free transit to Mumbai, Delhi, Bengaluru, and beyond.',
    },
  ];

  return (
    <section style={{ padding: '5.5rem 0', backgroundColor: 'var(--color-warm-ivory)' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span
            style={{
              fontSize: '0.8rem',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: 'var(--color-walnut-brown)',
              fontWeight: 700,
              display: 'block',
              marginBottom: '0.5rem',
            }}
          >
            The SS Crafts Standard
          </span>
          <h2 className="section-title">Why Craft Businesses Choose Us</h2>
          <p className="section-subtitle">
            Reliable engineering, authentic Indian craftsmanship, and direct WhatsApp support built for makers, gifting agencies, and event planners.
          </p>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '2rem',
          }}
        >
          {points.map((p, idx) => (
            <div
              key={idx}
              style={{
                backgroundColor: 'var(--color-cream-white)',
                padding: '2.25rem',
                borderRadius: 'var(--radius-lg)',
                border: '1px solid var(--color-border-subtle)',
                boxShadow: 'var(--shadow-card)',
                transition: 'var(--transition)',
              }}
              className="why-card"
            >
              <div
                style={{
                  width: '54px',
                  height: '54px',
                  borderRadius: '14px',
                  backgroundColor: 'rgba(138, 96, 69, 0.12)',
                  color: 'var(--color-walnut-brown)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '1.25rem',
                }}
              >
                {p.icon}
              </div>

              <h3
                style={{
                  fontFamily: 'var(--font-heading)',
                  fontSize: '1.2rem',
                  color: 'var(--color-espresso)',
                  marginBottom: '0.6rem',
                }}
              >
                {p.title}
              </h3>

              <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                {p.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .why-card:hover {
          transform: translateY(-4px);
          box-shadow: var(--shadow-hover);
          border-color: var(--color-walnut-brown);
        }
      `}</style>
    </section>
  );
}
