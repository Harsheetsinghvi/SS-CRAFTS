import { NextRequest, NextResponse } from 'next/server';
import { getStoreSettings, updateStoreSettings } from '@/lib/db';
import { checkAdminAuth } from '@/lib/auth';
import bcrypt from 'bcryptjs';

export async function GET() {
  try {
    const settings = getStoreSettings();
    // Exclude password hash from public response
    const { adminPasswordHash, ...publicSettings } = settings;
    return NextResponse.json({ success: true, settings: publicSettings });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Failed to fetch settings' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const admin = checkAdminAuth(req);
    if (!admin) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const updateData: any = { ...body };

    // If updating password
    if (body.newPassword && body.newPassword.trim().length >= 6) {
      updateData.adminPasswordHash = await bcrypt.hash(body.newPassword.trim(), 10);
      delete updateData.newPassword;
    } else {
      delete updateData.newPassword;
    }

    const updated = updateStoreSettings(updateData);
    const { adminPasswordHash, ...publicSettings } = updated;

    return NextResponse.json({ success: true, settings: publicSettings });
  } catch (error) {
    console.error('Failed to update settings:', error);
    return NextResponse.json({ success: false, error: 'Failed to update settings' }, { status: 500 });
  }
}
