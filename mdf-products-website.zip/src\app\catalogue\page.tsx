import React, { Suspense } from 'react';
import CatalogueView from './CatalogueView';
import { getAllProducts, getAllCategories, getStoreSettings } from '@/lib/db';

export const metadata = {
  title: 'MDF Products Catalogue | Boxes, Trays, Wedding Hampers & Art Bases',
  description: 'Explore the full catalogue of precision laser-cut MDF boxes, trousseau hampers, pre-marked art bases, and serving trays with direct WhatsApp ordering.',
};

export default function CataloguePage() {
  const products = getAllProducts();
  const categories = getAllCategories();
  const settings = getStoreSettings();

  return (
    <Suspense
      fallback={
        <div style={{ padding: '6rem 0', textAlign: 'center' }}>
          <div className="container">
            <h2 style={{ fontFamily: 'var(--font-heading)', color: 'var(--color-espresso)' }}>
              Loading MDF Catalogue...
            </h2>
          </div>
        </div>
      }
    >
      <CatalogueView
        initialProducts={products}
        categories={categories}
        whatsappNumber={settings.whatsappNumber}
      />
    </Suspense>
  );
}
