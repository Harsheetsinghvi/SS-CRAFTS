import React from 'react';

export const metadata = {
  title: 'Privacy Policy | SS Crafts',
  description: 'Our commitment to protecting your business details, custom design files, and contact privacy.',
};

export default function PrivacyPage() {
  return (
    <div style={{ backgroundColor: 'var(--color-warm-ivory)', padding: '4rem 0 6rem' }}>
      <div className="container" style={{ maxWidth: '840px' }}>
        <h1 className="display-title" style={{ fontSize: '2.4rem', marginBottom: '1rem' }}>
          Privacy Policy
        </h1>
        <p style={{ fontSize: '1rem', color: 'var(--color-text-muted)', marginBottom: '2.5rem' }}>
          Your data privacy and intellectual property are strictly safeguarded.
        </p>

        <div style={{ backgroundColor: '#FFFFFF', padding: '2.5rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-card)', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              1. Information We Collect
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              We collect contact information (such as your name, business name, phone number, and city) solely when you submit an inquiry form or interact with our WhatsApp buttons to facilitate quotations and order fulfillment.
            </p>
          </div>

          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              2. Custom Vector Designs & Proprietary Artwork
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              All CAD drawings, brand logos, wedding monograms, and custom laser vector files provided by customers remain the exclusive intellectual property of the respective client. We never resell or distribute private customer designs to third parties.
            </p>
          </div>

          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              3. WhatsApp Communications
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              WhatsApp interactions are conducted under WhatsApp's end-to-end encrypted messaging infrastructure. We do not spam or sell your phone number to telemarketers.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
