import React from 'react';

export const metadata = {
  title: 'Terms of Service & MDF Care Guide | SS Crafts',
  description: 'Terms of service, custom order payment policies, and proper care guidelines for MDF products.',
};

export default function TermsPage() {
  return (
    <div style={{ backgroundColor: 'var(--color-warm-ivory)', padding: '4rem 0 6rem' }}>
      <div className="container" style={{ maxWidth: '840px' }}>
        <h1 className="display-title" style={{ fontSize: '2.4rem', marginBottom: '1rem' }}>
          Terms of Service & MDF Care Guide
        </h1>
        <p style={{ fontSize: '1rem', color: 'var(--color-text-muted)', marginBottom: '2.5rem' }}>
          Ensuring long-lasting beauty and mutual business clarity.
        </p>

        <div style={{ backgroundColor: '#FFFFFF', padding: '2.5rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-card)', display: 'flex', flexDirection: 'column', gap: '2rem' }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              1. Catalogue Pricing & Custom Quotes
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              All prices listed on the catalogue are base ex-factory rates excluding applicable GST and freight charges unless stated otherwise in your custom quotation. Prices may vary based on market changes in raw MDF board sheets.
            </p>
          </div>

          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              2. Custom Laser Orders & Approval
            </h2>
            <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
              For bespoke products with custom branding or dimensions, production begins only after client sign-off on digital 2D CAD mockups or physical prototype approval. Custom orders are non-cancellable once raw boards are laser cut.
            </p>
          </div>

          <div>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.35rem', marginBottom: '0.6rem', color: 'var(--color-espresso)' }}>
              3. MDF Product Care Guide
            </h2>
            <ul style={{ paddingLeft: '1.5rem', fontSize: '0.9rem', color: 'var(--color-text-muted)', lineHeight: 1.7 }}>
              <li><strong>Moisture Care:</strong> While our pine MDF boards are moisture resistant, avoid direct submersion in water or leaving in damp standing puddles.</li>
              <li><strong>Cleaning:</strong> Wipe clean with a soft, dry micro-fiber cloth or lightly damp sponge. Avoid harsh chemical solvents or bleach.</li>
              <li><strong>Resin & Fluid Art:</strong> For raw sanded MDF bases, applying a light coat of clear gesso or PVA primer before heavy epoxy resin pours provides optimal edge sealing.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
