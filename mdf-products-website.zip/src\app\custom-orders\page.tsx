import React from 'react';
import CustomizerSection from '@/components/CustomizerSection';
import { getStoreSettings } from '@/lib/db';
import { Sparkles, CheckCircle2, Ruler, Cpu, Factory } from 'lucide-react';

export const metadata = {
  title: 'Custom MDF Sizing & Laser Cutting Services | SS Crafts',
  description: 'Order bespoke MDF boxes, trays, pre-marked art bases, piggy banks, cake toppers, and company logo laser cutting in custom dimensions and thickness.',
};

export default function CustomOrdersPage() {
  const settings = getStoreSettings();

  return (
    <div>
      <div style={{ backgroundColor: 'var(--color-espresso)', color: 'var(--color-sand-beige)', padding: '4.5rem 0 3.5rem' }}>
        <div className="container" style={{ textAlign: 'center', maxWidth: '800px' }}>
          <span style={{ fontSize: '0.8rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--color-caramel)', fontWeight: 700, display: 'block', marginBottom: '0.5rem' }}>
            Bespoke Fabrication
          </span>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 'clamp(2.2rem, 5vw, 3.2rem)', color: '#FFFFFF', marginBottom: '1rem' }}>
            Custom Orders & Precision Laser Cutting
          </h1>
          <p style={{ fontSize: '1.1rem', color: '#D4C9BC', lineHeight: 1.6 }}>
            Tailored dimensions, custom thicknesses (2.5mm to 18mm), brand logo engraving, and acrylic hybrid designs manufactured to your exact CAD/vector drawings.
          </p>
        </div>
      </div>

      <CustomizerSection whatsappNumber={settings.whatsappNumber} />

      <div style={{ padding: '5rem 0', backgroundColor: 'var(--color-cream-white)' }}>
        <div className="container" style={{ maxWidth: '960px' }}>
          <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '2rem', textAlign: 'center', marginBottom: '3rem' }}>
            Our CNC & Laser Capabilities
          </h2>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '2rem' }}>
            <div style={{ backgroundColor: 'var(--color-warm-ivory)', padding: '2rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
              <div style={{ color: 'var(--color-walnut-brown)', marginBottom: '1rem' }}><Cpu size={30} /></div>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', marginBottom: '0.5rem' }}>Vector File Formats</h3>
              <p style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                We accept Adobe Illustrator (.AI), CorelDRAW (.CDR), AutoCAD (.DXF/.DWG), and vector PDFs for direct laser cutting.
              </p>
            </div>

            <div style={{ backgroundColor: 'var(--color-warm-ivory)', padding: '2rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
              <div style={{ color: 'var(--color-walnut-brown)', marginBottom: '1rem' }}><Ruler size={30} /></div>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', marginBottom: '0.5rem' }}>Bed Size & Tolerances</h3>
              <p style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                Large format 8ft x 4ft CNC tables with 0.1mm optical laser tolerances, enabling smooth joints and delicate fretwork.
              </p>
            </div>

            <div style={{ backgroundColor: 'var(--color-warm-ivory)', padding: '2rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)' }}>
              <div style={{ color: 'var(--color-walnut-brown)', marginBottom: '1rem' }}><Factory size={30} /></div>
              <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', marginBottom: '0.5rem' }}>Prototyping & Sampling</h3>
              <p style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)', lineHeight: 1.6 }}>
                Pre-production physical sample units dispatched within 72 hours for fitment and dimensional verification.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
