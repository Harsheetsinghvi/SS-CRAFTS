'use client';

import React, { useState, useEffect } from 'react';
import { MessageCircle, Search, Filter, Phone, Calendar, CheckCircle2, User, Box } from 'lucide-react';
import { CustomerEnquiry } from '@/lib/types';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

export default function AdminEnquiriesPage() {
  const [enquiries, setEnquiries] = useState<CustomerEnquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('All');
  const [search, setSearch] = useState('');

  const fetchEnquiries = async () => {
    try {
      const res = await fetch('/api/enquiries');
      const data = await res.json();
      if (data.success) {
        setEnquiries(data.enquiries);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEnquiries();
  }, []);

  const handleStatusChange = async (id: string, status: CustomerEnquiry['status']) => {
    try {
      const res = await fetch('/api/enquiries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status }),
      });
      if (res.ok) {
        setEnquiries(prev => prev.map(e => e.id === id ? { ...e, status } : e));
      }
    } catch (e) {}
  };

  const filtered = enquiries.filter((e) => {
    if (statusFilter !== 'All' && e.status !== statusFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        e.productName.toLowerCase().includes(q) ||
        e.id.toLowerCase().includes(q) ||
        (e.customerName && e.customerName.toLowerCase().includes(q)) ||
        (e.customerPhone && e.customerPhone.includes(q))
      );
    }
    return true;
  });

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem', color: 'var(--color-espresso)', margin: 0 }}>
          Enquiries & Customer Leads
        </h1>
        <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginTop: '0.2rem' }}>
          Track every WhatsApp enquiry click, custom quote submission, and order discussion.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div
        style={{
          backgroundColor: '#FFFFFF',
          borderRadius: 'var(--radius-md)',
          padding: '1rem',
          border: '1px solid var(--color-border)',
          display: 'flex',
          gap: '1rem',
          flexWrap: 'wrap',
          marginBottom: '1.5rem',
        }}
      >
        <div style={{ flex: '1 1 260px', position: 'relative' }}>
          <Search size={16} style={{ position: 'absolute', top: '50%', left: '0.8rem', transform: 'translateY(-50%)', color: 'var(--color-text-light)' }} />
          <input
            type="text"
            placeholder="Search by product, customer name or phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="form-input"
            style={{ paddingLeft: '2.4rem', padding: '0.5rem 0.5rem 0.5rem 2.4rem', fontSize: '0.88rem' }}
          />
        </div>

        <div style={{ minWidth: '180px' }}>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="form-select"
            style={{ padding: '0.5rem', fontSize: '0.88rem' }}
          >
            <option value="All">All Statuses ({enquiries.length})</option>
            <option value="New">New</option>
            <option value="In Discussion">In Discussion</option>
            <option value="Sample Dispatched">Sample Dispatched</option>
            <option value="Order Confirmed">Order Confirmed</option>
            <option value="Archived">Archived</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="admin-table-wrapper" style={{ boxShadow: 'var(--shadow-sm)' }}>
        <table className="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Product Details</th>
              <th>Qty & Price</th>
              <th>Dimensions & Finish</th>
              <th>Customer Details</th>
              <th>Status</th>
              <th>Date</th>
              <th>WhatsApp Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((enq) => {
              const customerPhoneDigits = enq.customerPhone ? sanitizeWhatsAppNumber(enq.customerPhone) : '';
              const replyUrl = customerPhoneDigits
                ? `https://wa.me/${customerPhoneDigits}?text=${encodeURIComponent(`Hello ${enq.customerName || ''}, thank you for your enquiry regarding ${enq.productName}. We are glad to help you with pricing and delivery timelines.`)}`
                : null;

              return (
                <tr key={enq.id}>
                  <td style={{ fontFamily: 'monospace', fontWeight: 600, color: 'var(--color-walnut-brown)' }}>
                    {enq.id}
                  </td>
                  <td>
                    <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>{enq.productName}</strong>
                    <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>SKU: {enq.productId}</span>
                  </td>
                  <td>
                    <strong>{enq.quantity} pcs</strong>
                    {enq.productPrice > 0 && (
                      <span style={{ display: 'block', fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>
                        ₹{enq.productPrice * enq.quantity} est.
                      </span>
                    )}
                  </td>
                  <td style={{ fontSize: '0.82rem' }}>
                    <span>{enq.dimensions}</span>
                    <span style={{ display: 'block', color: 'var(--color-walnut-brown)' }}>{enq.finish}</span>
                    {enq.customizationText && (
                      <span style={{ display: 'block', color: 'var(--color-text-muted)', fontStyle: 'italic', maxWidth: '200px' }}>
                        &ldquo;{enq.customizationText}&rdquo;
                      </span>
                    )}
                  </td>
                  <td style={{ fontSize: '0.85rem' }}>
                    <strong>{enq.customerName || 'Direct WhatsApp Visitor'}</strong>
                    {enq.customerPhone && (
                      <span style={{ display: 'block', color: 'var(--color-text-muted)', fontSize: '0.8rem' }}>
                        {enq.customerPhone}
                      </span>
                    )}
                    {enq.customerCity && (
                      <span style={{ display: 'block', color: 'var(--color-text-light)', fontSize: '0.75rem' }}>
                        {enq.customerCity}
                      </span>
                    )}
                  </td>
                  <td>
                    <select
                      value={enq.status}
                      onChange={(e) => handleStatusChange(enq.id, e.target.value as any)}
                      style={{
                        fontSize: '0.8rem',
                        padding: '0.3rem 0.5rem',
                        borderRadius: 'var(--radius-sm)',
                        border: '1px solid var(--color-border)',
                        backgroundColor:
                          enq.status === 'Order Confirmed' ? '#E6EFE8' :
                          enq.status === 'In Discussion' ? '#FEF3C7' : '#FFFFFF',
                        color:
                          enq.status === 'Order Confirmed' ? 'var(--color-whatsapp)' :
                          enq.status === 'In Discussion' ? '#92400E' : 'var(--color-espresso)',
                        fontWeight: 600,
                      }}
                    >
                      <option value="New">New</option>
                      <option value="In Discussion">In Discussion</option>
                      <option value="Sample Dispatched">Sample Dispatched</option>
                      <option value="Order Confirmed">Order Confirmed</option>
                      <option value="Archived">Archived</option>
                    </select>
                  </td>
                  <td style={{ fontSize: '0.8rem', color: 'var(--color-text-light)', whiteSpace: 'nowrap' }}>
                    {new Date(enq.createdAt).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td>
                    {replyUrl ? (
                      <a
                        href={replyUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-whatsapp btn-sm"
                        style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem' }}
                      >
                        <MessageCircle size={13} />
                        <span>Reply</span>
                      </a>
                    ) : (
                      <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>Web Click</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
