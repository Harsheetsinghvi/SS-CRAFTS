import React from 'react';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { getProductById, getAllProducts, getStoreSettings } from '@/lib/db';
import ProductDetailClient from './ProductDetailClient';
import { ArrowLeft, Box, ShieldCheck, Truck, Sparkles } from 'lucide-react';
import type { Metadata } from 'next';

interface ProductPageProps {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const { id } = await params;
  const product = getProductById(id);

  if (!product) {
    return { title: 'Product Not Found | SS Crafts' };
  }

  return {
    title: `${product.name} | SS Crafts`,
    description: `${product.name} (${product.dimensions.length}x${product.dimensions.width}x${product.dimensions.height} ${product.dimensions.unit}, ${product.mdfThickness}). ${product.description.slice(0, 150)}...`,
    openGraph: {
      title: `${product.name} - ₹${product.price} | SS Crafts`,
      description: product.description,
      images: product.images?.[0] ? [{ url: product.images[0] }] : [],
    },
  };
}

export default async function ProductDetailPage({ params }: ProductPageProps) {
  const { id } = await params;
  const product = getProductById(id);

  if (!product) {
    notFound();
  }

  const settings = getStoreSettings();
  const allProducts = getAllProducts();
  const relatedProducts = allProducts
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <div style={{ padding: '3rem 0 6rem', backgroundColor: 'var(--color-warm-ivory)' }}>
      <div className="container">
        {/* Breadcrumb Navigation */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '2rem', fontSize: '0.88rem' }}>
          <Link href="/" style={{ color: 'var(--color-text-muted)' }}>Home</Link>
          <span style={{ color: 'var(--color-text-light)' }}>/</span>
          <Link href="/catalogue" style={{ color: 'var(--color-text-muted)' }}>Catalogue</Link>
          <span style={{ color: 'var(--color-text-light)' }}>/</span>
          <Link href={`/catalogue?category=${encodeURIComponent(product.category)}`} style={{ color: 'var(--color-text-muted)' }}>
            {product.category}
          </Link>
          <span style={{ color: 'var(--color-text-light)' }}>/</span>
          <span style={{ color: 'var(--color-walnut-brown)', fontWeight: 600 }}>{product.name}</span>
        </div>

        {/* Client Product Configurator & Specs */}
        <ProductDetailClient
          product={product}
          whatsappNumber={settings.whatsappNumber}
        />

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div style={{ marginTop: '5rem', borderTop: '1px solid var(--color-border)', paddingTop: '3.5rem' }}>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.8rem', marginBottom: '2rem' }}>
              Similar Products in {product.category}
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '1.75rem' }}>
              {relatedProducts.map((rel) => (
                <Link
                  key={rel.id}
                  href={`/product/${rel.id}`}
                  style={{
                    backgroundColor: '#FFFFFF',
                    borderRadius: 'var(--radius-md)',
                    overflow: 'hidden',
                    border: '1px solid var(--color-border-subtle)',
                    boxShadow: 'var(--shadow-card)',
                  }}
                >
                  <div style={{ position: 'relative', width: '100%', paddingTop: '75%' }}>
                    <Image src={rel.images[0]} alt={rel.name} fill style={{ objectFit: 'cover' }} />
                  </div>
                  <div style={{ padding: '1rem' }}>
                    <h4 style={{ fontFamily: 'var(--font-heading)', fontSize: '1rem', marginBottom: '0.3rem', color: 'var(--color-espresso)' }}>
                      {rel.name}
                    </h4>
                    <span style={{ fontWeight: 700, color: 'var(--color-espresso)' }}>₹{rel.price}</span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
