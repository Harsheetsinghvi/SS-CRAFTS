'use client';

import React, { useState } from 'react';
import { Mail, Phone, MapPin, MessageCircle, Clock, ShieldCheck, Check } from 'lucide-react';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const whatsappNum = '919313229609';
  const cleanPhone = sanitizeWhatsAppNumber(whatsappNum);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);

    const msg = [
      'Hello SS Crafts,',
      `Name: ${formData.name}`,
      `Phone: ${formData.phone}`,
      formData.city ? `City: ${formData.city}` : '',
      `Message: ${formData.message}`,
    ].filter(Boolean).join('\n');

    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  return (
    <div style={{ backgroundColor: 'var(--color-warm-ivory)', minHeight: '80vh', padding: '4rem 0 6rem' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <span style={{ fontSize: '0.8rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--color-walnut-brown)', fontWeight: 700, display: 'block', marginBottom: '0.4rem' }}>
            Get in Touch
          </span>
          <h1 className="display-title" style={{ fontSize: 'clamp(2.2rem, 4vw, 3rem)' }}>
            Workshop & Direct Inquiries
          </h1>
          <p className="section-subtitle">
            Have a custom laser inquiry, need product samples, or want to place bulk orders? Connect with us directly.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '3rem' }}>
          {/* Workshop Details Card */}
          <div style={{ backgroundColor: '#FFFFFF', padding: '2.5rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', marginBottom: '1.5rem', color: 'var(--color-espresso)' }}>
              Studio & Factory Location
            </h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', fontSize: '0.95rem' }}>
              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <MapPin size={22} style={{ color: 'var(--color-walnut-brown)', flexShrink: 0, marginTop: '2px' }} />
                <div>
                  <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>Works & Registered Office:</strong>
                  <span style={{ color: 'var(--color-text-muted)' }}>
                    Craftsman Industrial Hub, Ahmedabad, Gujarat &ndash; 382445, India
                  </span>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <Phone size={20} style={{ color: 'var(--color-walnut-brown)', flexShrink: 0 }} />
                <div>
                  <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>Direct Hotline:</strong>
                  <a href="tel:+919313229609" style={{ color: 'var(--color-text-muted)' }}>+91 93132 29609</a>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <MessageCircle size={20} style={{ color: 'var(--color-whatsapp)', flexShrink: 0 }} />
                <div>
                  <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>WhatsApp Orders:</strong>
                  <a
                    href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent('Hello SS Crafts, I would like to inquire about an order.')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ color: 'var(--color-whatsapp)', fontWeight: 600 }}
                  >
                    +91 93132 29609 (Instant Reply)
                  </a>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <Mail size={20} style={{ color: 'var(--color-walnut-brown)', flexShrink: 0 }} />
                <div>
                  <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>Email Support:</strong>
                  <a href="mailto:sscrafts104@gmail.com" style={{ color: 'var(--color-text-muted)' }}>sscrafts104@gmail.com</a>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '0.85rem' }}>
                <Clock size={20} style={{ color: 'var(--color-walnut-brown)', flexShrink: 0 }} />
                <div>
                  <strong style={{ display: 'block', color: 'var(--color-espresso)' }}>Working Hours:</strong>
                  <span style={{ color: 'var(--color-text-muted)' }}>Monday &ndash; Saturday: 9:30 AM &ndash; 7:00 PM IST</span>
                </div>
              </div>
            </div>

            <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: 'var(--color-warm-ivory)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--color-border-subtle)', fontSize: '0.82rem', color: 'var(--color-walnut-brown)' }}>
              <strong>GSTIN:</strong> 24AAJCV1234D1Z2 &bull; MSME Registered Manufacturer
            </div>
          </div>

          {/* Quick Contact / Message Form */}
          <div style={{ backgroundColor: '#FFFFFF', padding: '2.5rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
            <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.4rem', marginBottom: '0.5rem', color: 'var(--color-espresso)' }}>
              Send an Inquiry
            </h2>
            <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem' }}>
              Fill in your details below and hit submit to connect instantly on WhatsApp.
            </p>

            {submitted ? (
              <div style={{ textAlign: 'center', padding: '2rem 1rem' }}>
                <div style={{ width: '48px', height: '48px', borderRadius: '50%', backgroundColor: '#E6EFE8', color: 'var(--color-whatsapp)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem' }}>
                  <Check size={24} />
                </div>
                <h3 style={{ fontFamily: 'var(--font-heading)', fontSize: '1.25rem', marginBottom: '0.5rem' }}>Thank You!</h3>
                <p style={{ fontSize: '0.9rem', color: 'var(--color-text-muted)', marginBottom: '1rem' }}>
                  We opened WhatsApp with your inquiry. Feel free to attach pictures or CAD files there.
                </p>
                <button onClick={() => setSubmitted(false)} className="btn btn-secondary btn-sm">
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div>
                  <label className="form-label">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Priyanshu Sharma"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="form-input"
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                  <div>
                    <label className="form-label">WhatsApp Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="10-digit mobile"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="form-input"
                    />
                  </div>
                  <div>
                    <label className="form-label">City / State</label>
                    <input
                      type="text"
                      placeholder="e.g. Mumbai, MH"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="form-input"
                    />
                  </div>
                </div>

                <div>
                  <label className="form-label">Product / Requirement *</label>
                  <textarea
                    required
                    rows={4}
                    placeholder="Tell us what you're looking for (box type, sizes, quantities, deadline)..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="form-textarea"
                  />
                </div>

                <button type="submit" className="btn btn-whatsapp btn-lg" style={{ justifyContent: 'center' }}>
                  <MessageCircle size={18} />
                  <span>Send via WhatsApp</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
