import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Box, Factory, ShieldCheck, HeartHandshake, Sparkles, MessageCircle, ArrowRight } from 'lucide-react';
import { getStoreSettings } from '@/lib/db';
import { sanitizeWhatsAppNumber } from '@/lib/whatsapp';

export const metadata = {
  title: 'About SS Crafts | Precision MDF Craftsmanship in India',
  description: 'Learn about our passion for engineering high-density MDF products, laser cut art bases, luxury boxes, and sustainable wooden craft solutions.',
};

export default function AboutPage() {
  const settings = getStoreSettings();
  const cleanPhone = sanitizeWhatsAppNumber(settings.whatsappNumber);

  return (
    <div>
      {/* Header Banner */}
      <div style={{ backgroundColor: 'var(--color-espresso)', color: 'var(--color-sand-beige)', padding: '5rem 0 4rem' }}>
        <div className="container" style={{ textAlign: 'center', maxWidth: '820px' }}>
          <span style={{ fontSize: '0.8rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--color-caramel)', fontWeight: 700, display: 'block', marginBottom: '0.5rem' }}>
            Artisan Roots &bull; Modern Engineering
          </span>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 'clamp(2.2rem, 5vw, 3.4rem)', color: '#FFFFFF', marginBottom: '1.25rem' }}>
            Crafting Ideas Into Beautiful MDF Products
          </h1>
          <p style={{ fontSize: '1.15rem', color: '#D4C9BC', lineHeight: 1.65 }}>
            Born from an appreciation for authentic Indian craft and modern CNC engineering, SS Crafts delivers high-density MDF blanks, packaging boxes, and bespoke laser cutting for creators and enterprises nationwide.
          </p>
        </div>
      </div>

      {/* Philosophy & Craft Section */}
      <div style={{ padding: '6rem 0', backgroundColor: 'var(--color-warm-ivory)' }}>
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '4rem', alignItems: 'center' }}>
            <div>
              <span style={{ fontSize: '0.8rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--color-walnut-brown)', fontWeight: 700, display: 'block', marginBottom: '0.5rem' }}>
                Our Heritage
              </span>
              <h2 className="section-title">Why Engineered Pine MDF?</h2>
              <p style={{ fontSize: '0.98rem', color: 'var(--color-text-muted)', lineHeight: 1.7, marginBottom: '1.25rem' }}>
                Traditional raw wood often cracks, warps under tropical humidity, and splinters. We specifically source <strong>high-density, calibrated Pine MDF boards</strong> that offer an isotropic structure with zero grain orientation flaws.
              </p>
              <p style={{ fontSize: '0.98rem', color: 'var(--color-text-muted)', lineHeight: 1.7, marginBottom: '2rem' }}>
                This creates the ultimate canvas for resin artists, Pichwai and Lippan creators, gourmet confectionery brands, and luxury wedding planners who demand microscopic laser precision and seamless jointing.
              </p>

              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                <Link href="/catalogue" className="btn btn-primary">
                  <span>Explore Catalogue</span>
                  <ArrowRight size={16} />
                </Link>
                <a
                  href={`https://wa.me/${cleanPhone}?text=${encodeURIComponent('Hello SS Crafts, I would like to learn more about your manufacturing setup and product catalogue.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-whatsapp"
                >
                  <MessageCircle size={18} />
                  <span>Chat With Us</span>
                </a>
              </div>
            </div>

            <div style={{ position: 'relative', width: '100%', height: '420px', borderRadius: '24px', overflow: 'hidden', boxShadow: 'var(--shadow-lg)', border: '6px solid #FFFFFF' }}>
              <Image
                src="https://images.unsplash.com/photo-1590402494682-cd3fb53b1f70?auto=format&fit=crop&w=1000&q=80"
                alt="MDF Craftsmanship in Studio"
                fill
                style={{ objectFit: 'cover' }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
