import React from 'react';
import BulkGiftingSection from '@/components/BulkGiftingSection';
import { getStoreSettings } from '@/lib/db';
import { Building2, Gift, Check, ShieldCheck, Truck, Sparkles } from 'lucide-react';

export const metadata = {
  title: 'Corporate Gifting & Bulk MDF Hampers | SS Crafts',
  description: 'Custom logo engraved MDF boxes, executive hampers, Diwali packaging, Rakshabandhan boxes, awards, and event favours with wholesale tier pricing.',
};

export default function BulkGiftingPage() {
  const settings = getStoreSettings();

  return (
    <div>
      <div style={{ backgroundColor: 'var(--color-espresso)', color: 'var(--color-sand-beige)', padding: '4.5rem 0 3.5rem' }}>
        <div className="container" style={{ textAlign: 'center', maxWidth: '800px' }}>
          <span style={{ fontSize: '0.8rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--color-caramel)', fontWeight: 700, display: 'block', marginBottom: '0.5rem' }}>
            Volume Solutions
          </span>
          <h1 style={{ fontFamily: 'var(--font-heading)', fontSize: 'clamp(2.2rem, 5vw, 3.2rem)', color: '#FFFFFF', marginBottom: '1rem' }}>
            Corporate Gifting & Wholesale Hampers
          </h1>
          <p style={{ fontSize: '1.1rem', color: '#D4C9BC', lineHeight: 1.6 }}>
            Premium packaging suites for annual festive gifting, executive employee onboarding, wedding planners, and retail gourmet brands.
          </p>
        </div>
      </div>

      <BulkGiftingSection whatsappNumber={settings.whatsappNumber} />

      <div style={{ padding: '5rem 0', backgroundColor: 'var(--color-warm-ivory)' }}>
        <div className="container">
          <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
            <h2 className="section-title">Wholesale Volume Tiers</h2>
            <p className="section-subtitle">
              Scale your gifting budget effectively with direct factory quantity brackets.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: '2rem' }}>
            <div style={{ backgroundColor: '#FFFFFF', padding: '2rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <span className="badge badge-custom" style={{ marginBottom: '1rem' }}>Tier 1 &bull; Boutique Batch</span>
              <h3 style={{ fontSize: '1.4rem', fontFamily: 'var(--font-heading)', marginBottom: '0.5rem' }}>50 &ndash; 150 Pcs</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem', lineHeight: 1.5 }}>
                Ideal for luxury wedding trousseau, boutique studio hampers, and small team onboarding.
              </p>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.85rem' }}>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Standard Catalogue Finishes</li>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Custom Lid Monogramming</li>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> 3-4 Days Dispatch</li>
              </ul>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: '2rem', borderRadius: 'var(--radius-lg)', border: '2px solid var(--color-walnut-brown)', boxShadow: 'var(--shadow-lg)' }}>
              <span className="badge badge-bestseller" style={{ marginBottom: '1rem' }}>★ Most Popular Tier</span>
              <h3 style={{ fontSize: '1.4rem', fontFamily: 'var(--font-heading)', marginBottom: '0.5rem' }}>150 &ndash; 500 Pcs</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem', lineHeight: 1.5 }}>
                Designed for corporate Diwali gifts, festival hampers, and event giveaways.
              </p>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.85rem' }}>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Custom Dimensions Feasible</li>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Free Company Logo Engraving</li>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Free Pre-production Prototype</li>
              </ul>
            </div>

            <div style={{ backgroundColor: '#FFFFFF', padding: '2rem', borderRadius: 'var(--radius-lg)', border: '1px solid var(--color-border)', boxShadow: 'var(--shadow-card)' }}>
              <span className="badge badge-custom" style={{ marginBottom: '1rem' }}>Tier 3 &bull; Enterprise</span>
              <h3 style={{ fontSize: '1.4rem', fontFamily: 'var(--font-heading)', marginBottom: '0.5rem' }}>500 &ndash; 5000+ Pcs</h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)', marginBottom: '1.5rem', lineHeight: 1.5 }}>
                Direct factory manufacturing rates with dedicated production lines and pallet delivery.
              </p>
              <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.5rem', fontSize: '0.85rem' }}>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Maximum Volume Cost Advantage</li>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Custom Moldings & Hardware</li>
                <li style={{ display: 'flex', gap: '0.5rem' }}><Check size={16} style={{ color: 'var(--color-whatsapp)' }} /> Palletised Doorstep Logistics</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
